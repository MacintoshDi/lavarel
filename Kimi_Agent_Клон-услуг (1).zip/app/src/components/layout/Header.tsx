import { useState } from 'react';
import { Search, Menu, X, User } from 'lucide-react';

interface HeaderProps {
  currentPage: string;
  onPageChange: (page: string, params?: any) => void;
  onMenuClick: () => void;
  sidebarOpen: boolean;
}

export function Header({ currentPage, onPageChange, onMenuClick, sidebarOpen }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <>
      {/* Top banner */}
      <div className="bg-[#8B5CF6] text-white text-center py-2 text-sm">
        <span>🎉 Сервіс побутових послуг — знайдіть надійного майстра за 5 хвилин!</span>
      </div>

      {/* Main header */}
      <header className="bg-white border-b border-gray-100 sticky top-0 z-40">
        <div className="flex items-center justify-between px-4 lg:px-6 py-3">
          {/* Left: Menu button + Logo */}
          <div className="flex items-center gap-4">
            <button 
              onClick={onMenuClick}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors lg:hidden"
            >
              {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            
            <div 
              className="flex items-center gap-2 cursor-pointer"
              onClick={() => onPageChange('home')}
            >
              <div className="w-8 h-8 bg-[#8B5CF6] rounded-lg flex items-center justify-center">
                <span className="text-white text-lg">⚡</span>
              </div>
              <span className="font-bold text-xl text-gray-800">Servis<span className="text-[#8B5CF6]">.ua</span></span>
            </div>
          </div>

          {/* Center: Navigation (hidden on mobile) */}
          <nav className="hidden lg:flex items-center gap-1">
            {[
              { id: 'categories', label: 'Послуги' },
              { id: 'orders', label: 'Завдання' },
              { id: 'how-it-works', label: 'Як це працює' },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => onPageChange(item.id)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  currentPage === item.id
                    ? 'bg-[#8B5CF6]/10 text-[#8B5CF6]'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Right: Search + Auth */}
          <div className="flex items-center gap-3">
            {/* Search (hidden on mobile) */}
            <div className="hidden md:flex items-center relative">
              <Search className="absolute left-3 text-gray-400" size={16} />
              <input
                type="text"
                placeholder="Пошук послуг..."
                className="pl-9 pr-4 py-2 bg-gray-100 rounded-lg text-sm w-48 focus:bg-white focus:ring-2 focus:ring-[#8B5CF6]/20 transition-all"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Auth buttons */}
            <button 
              onClick={() => onPageChange('login')}
              className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <User size={18} />
              <span className="hidden sm:inline text-sm font-medium">Увійти</span>
            </button>
            
            <button 
              onClick={() => onPageChange('create-order')}
              className="btn-primary hidden sm:flex items-center gap-2"
            >
              <span>Створити завдання</span>
            </button>
          </div>
        </div>
      </header>
    </>
  );
}
