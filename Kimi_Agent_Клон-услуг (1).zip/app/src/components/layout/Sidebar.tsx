import { sidebarNav } from '@/data/servicesData';
import { Home, Grid3X3, Package, FolderOpen, HelpCircle, MessageCircle } from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  onPageChange: (page: string, params?: any) => void;
  isOpen: boolean;
  onClose: () => void;
}

const iconMap: Record<string, React.ElementType> = {
  '🏠': Home,
  '📋': Grid3X3,
  '📦': Package,
  '📁': FolderOpen,
  '❓': HelpCircle,
  '💬': MessageCircle,
};

export function Sidebar({ currentPage, onPageChange, isOpen, onClose }: SidebarProps) {
  const handleClick = (page: string) => {
    onPageChange(page);
    onClose();
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/20 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside 
        className={`
          fixed lg:sticky top-[57px] lg:top-0 left-0 
          w-64 h-[calc(100vh-57px)] lg:h-[calc(100vh-33px)]
          bg-white border-r border-gray-100
          transform transition-transform duration-300 z-50
          ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
          overflow-y-auto
        `}
      >
        <div className="p-4">
          {/* Navigation */}
          <nav className="space-y-1">
            {sidebarNav.map((item) => {
              const Icon = iconMap[item.icon] || Home;
              const isActive = currentPage === item.id;
              
              return (
                <button
                  key={item.id}
                  onClick={() => handleClick(item.id)}
                  className={`
                    w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all
                    ${isActive 
                      ? 'bg-[#8B5CF6] text-white shadow-lg shadow-[#8B5CF6]/25' 
                      : 'text-gray-600 hover:bg-gray-100 hover:text-[#8B5CF6]'
                    }
                  `}
                >
                  <Icon size={18} />
                  <span>{item.name}</span>
                </button>
              );
            })}
          </nav>

          {/* Divider */}
          <div className="my-4 border-t border-gray-100" />

          {/* Categories shortcut */}
          <div className="px-4 mb-3">
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Популярні послуги</span>
          </div>
          <div className="space-y-1">
            {[
              { name: 'Ремонт квартири', icon: '🔨', category: 'remont' },
              { name: 'Сантехніка', icon: '🚿', category: 'santehnika' },
              { name: 'Електрика', icon: '⚡', category: 'elektrika' },
              { name: 'Прибирання', icon: '🧹', category: 'uborka' },
            ].map((cat) => (
              <button
                key={cat.category}
                onClick={() => handleClick('categories')}
                className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm text-gray-600 hover:bg-gray-100 hover:text-[#8B5CF6] transition-all"
              >
                <span>{cat.icon}</span>
                <span>{cat.name}</span>
              </button>
            ))}
          </div>

          {/* Footer */}
          <div className="mt-auto pt-8 pb-4 px-4">
            <div className="bg-[#F5F3FF] rounded-xl p-4">
              <p className="text-xs text-gray-500 mb-2">Потрібна допомога?</p>
              <button 
                onClick={() => handleClick('faq')}
                className="text-sm font-medium text-[#8B5CF6] hover:underline"
              >
                Зв'яжіться з нами →
              </button>
            </div>
            <p className="text-xs text-gray-400 mt-4 text-center">
              © 2024 Servis.ua
            </p>
          </div>
        </div>
      </aside>
    </>
  );
}
