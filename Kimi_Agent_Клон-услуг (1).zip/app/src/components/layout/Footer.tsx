import { Phone, Mail, MapPin, Facebook, Instagram } from 'lucide-react';

interface FooterProps {
  onPageChange: (page: string, params?: any) => void;
}

export function Footer({ onPageChange }: FooterProps) {
  const footerLinks = {
    services: [
      { label: 'Ремонт та будівництво', page: 'categories', params: { category: 'remont' } },
      { label: 'Сантехніка', page: 'categories', params: { category: 'santehnika' } },
      { label: 'Електрика', page: 'categories', params: { category: 'elektrika' } },
      { label: 'Прибирання', page: 'categories', params: { category: 'uborka' } },
      { label: 'Вантажники', page: 'categories', params: { category: 'gruzchiki' } },
      { label: 'Меблі', page: 'categories', params: { category: 'mebel' } },
    ],
    info: [
      { label: 'Як це працює', page: 'how-it-works' },
      { label: 'Створити завдання', page: 'create-order' },
      { label: 'Всі послуги', page: 'categories' },
      { label: 'Завдання', page: 'orders' },
      { label: 'Про нас', page: 'about' },
      { label: 'Контакти', page: 'contacts' },
    ],
    support: [
      { label: 'Допомога (FAQ)', page: 'faq' },
      { label: 'Умови використання', page: 'terms' },
      { label: 'Політика конфіденційності', page: 'privacy' },
    ],
  };

  return (
    <footer className="bg-[#2c3e50] text-white">
      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo & contacts */}
          <div>
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-[#27ae60] rounded-lg flex items-center justify-center mr-2">
                <span className="text-white text-xl">🐗</span>
              </div>
              <div>
                <div className="font-bold text-lg leading-tight">Kabanchik</div>
                <div className="text-[#27ae60] text-xs">послуги для дому</div>
              </div>
            </div>
            <p className="text-gray-400 text-sm mb-4">
              Маркетплейс побутових послуг. Знаходимо надійних виконавців для ваших завдань.
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-gray-300">
                <Phone size={16} />
                <span>0 800 123 456</span>
              </div>
              <div className="flex items-center gap-2 text-gray-300">
                <Mail size={16} />
                <span>support@kabanchik.ua</span>
              </div>
              <div className="flex items-center gap-2 text-gray-300">
                <MapPin size={16} />
                <span>м. Київ, вул. Хрещатик 1</span>
              </div>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-bold mb-4">Послуги</h4>
            <ul className="space-y-2">
              {footerLinks.services.map((link, idx) => (
                <li key={idx}>
                  <button 
                    onClick={() => onPageChange(link.page, link.params)}
                    className="text-gray-300 hover:text-[#27ae60] text-sm transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Info */}
          <div>
            <h4 className="font-bold mb-4">Інформація</h4>
            <ul className="space-y-2">
              {footerLinks.info.map((link, idx) => (
                <li key={idx}>
                  <button 
                    onClick={() => onPageChange(link.page)}
                    className="text-gray-300 hover:text-[#27ae60] text-sm transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-bold mb-4">Підтримка</h4>
            <ul className="space-y-2">
              {footerLinks.support.map((link, idx) => (
                <li key={idx}>
                  <button 
                    onClick={() => onPageChange(link.page)}
                    className="text-gray-300 hover:text-[#27ae60] text-sm transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
            
            {/* Social */}
            <div className="mt-6">
              <h4 className="font-bold mb-3">Ми в соцмережах</h4>
              <div className="flex gap-3">
                <button className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-[#27ae60] transition-colors">
                  <Facebook size={20} />
                </button>
                <button className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-[#27ae60] transition-colors">
                  <Instagram size={20} />
                </button>
                <button className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-[#27ae60] transition-colors">
                  <span className="text-lg">✈️</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-400 text-sm">
            © 2024 Kabanchik.ua. Всі права захищені.
          </p>
          <div className="flex items-center gap-4 text-sm text-gray-400">
            <button onClick={() => onPageChange('terms')} className="hover:text-white">Умови використання</button>
            <span>|</span>
            <button onClick={() => onPageChange('privacy')} className="hover:text-white">Політика конфіденційності</button>
          </div>
        </div>
      </div>
    </footer>
  );
}
