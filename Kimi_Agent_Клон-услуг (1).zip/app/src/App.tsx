import { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { Sidebar } from '@/components/layout/Sidebar';
import { HomePage } from '@/pages/HomePage';
import { CategoriesPage } from '@/pages/CategoriesPage';
import { PriceTablePage } from '@/pages/PriceTablePage';
import { CreateOrderPage } from '@/pages/CreateOrderPage';
import { MyOrdersPage } from '@/pages/MyOrdersPage';
import { LoginPage } from '@/pages/LoginPage';
import { FAQPage } from '@/pages/FAQPage';
import { HowItWorksPage } from '@/pages/HowItWorksPage';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [pageParams, setPageParams] = useState<any>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handlePageChange = (page: string, params?: any) => {
    setCurrentPage(page);
    setPageParams(params);
    setSidebarOpen(false);
    window.scrollTo(0, 0);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onPageChange={handlePageChange} />;
      case 'categories':
        return <CategoriesPage onPageChange={handlePageChange} selectedCategory={pageParams?.category} />;
      case 'price-table':
        return (
          <PriceTablePage 
            onPageChange={handlePageChange} 
            categoryId={pageParams?.categoryId}
            subcategoryId={pageParams?.subcategoryId}
          />
        );
      case 'service-detail':
        return (
          <PriceTablePage 
            onPageChange={handlePageChange} 
            categoryId={pageParams?.categoryId}
            subcategoryId={pageParams?.subcategoryId}
          />
        );
      case 'create-order':
        return <CreateOrderPage onPageChange={handlePageChange} preselectedService={pageParams?.service} />;
      case 'orders':
        return <MyOrdersPage onPageChange={handlePageChange} />;
      case 'my-orders':
        return <MyOrdersPage onPageChange={handlePageChange} />;
      case 'how-it-works':
        return <HowItWorksPage onPageChange={handlePageChange} />;
      case 'login':
        return <LoginPage onPageChange={handlePageChange} />;
      case 'signup':
        return <LoginPage onPageChange={handlePageChange} />;
      case 'faq':
        return <FAQPage onPageChange={handlePageChange} />;
      case 'about':
        return <HowItWorksPage onPageChange={handlePageChange} />;
      case 'contacts':
        return <FAQPage onPageChange={handlePageChange} />;
      case 'terms':
      case 'privacy':
        return <FAQPage onPageChange={handlePageChange} />;
      default:
        return <HomePage onPageChange={handlePageChange} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F3FF]">
      <Header 
        currentPage={currentPage} 
        onPageChange={handlePageChange} 
        onMenuClick={() => setSidebarOpen(!sidebarOpen)}
        sidebarOpen={sidebarOpen}
      />
      
      <div className="flex">
        <Sidebar 
          currentPage={currentPage} 
          onPageChange={handlePageChange}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />
        
        <main className="flex-1 min-h-[calc(100vh-57px)] p-4 lg:p-6">
          <div className="max-w-5xl mx-auto">
            {renderPage()}
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;
