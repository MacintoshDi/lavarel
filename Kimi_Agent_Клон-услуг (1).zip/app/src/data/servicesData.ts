// Многоуровневая структура категорий услуг
export interface ServiceCategory {
  id: string;
  name: string;
  icon: string;
  description?: string;
  subcategories?: ServiceCategory[];
  services?: Service[];
}

export interface Service {
  id: string;
  name: string;
  description: string;
  basePrice: number;
  unit: string;
  priceFrom: boolean;
  popular?: boolean;
}

export interface PriceTable {
  id: string;
  name: string;
  description: string;
  columns: string[];
  rows: PriceRow[];
}

export interface PriceRow {
  service: string;
  prices: (string | number)[];
  note?: string;
}

// Категории услуг
export const serviceCategories: ServiceCategory[] = [
  {
    id: 'remont',
    name: 'Ремонт та будівництво',
    icon: '🔨',
    description: 'Ремонт квартир, будинків, офісів та комерційних приміщень',
    subcategories: [
      {
        id: 'remont-kvartiry',
        name: 'Ремонт квартири',
        icon: '🏠',
        description: 'Косметичний, капітальний та євроремонт квартир',
        services: [
          { id: 'kosmeticheskiy', name: 'Косметичний ремонт', description: 'Фарбування стін, заміна ламінату, оновлення сантехніки', basePrice: 3500, unit: 'м²', priceFrom: true, popular: true },
          { id: 'kapitalnyy', name: 'Капітальний ремонт', description: 'Повна заміна всіх комунікацій, перепланування, чорнові роботи', basePrice: 5500, unit: 'м²', priceFrom: true, popular: true },
          { id: 'evroremont', name: 'Євроремонт', description: 'Дизайнерський ремонт з використанням преміум матеріалів', basePrice: 8500, unit: 'м²', priceFrom: true },
          { id: 'studiya', name: 'Ремонт студії', description: 'Ремонт однокімнатної квартири-студії', basePrice: 4500, unit: 'м²', priceFrom: true },
        ]
      },
      {
        id: 'remont-komnaty',
        name: 'Ремонт кімнат',
        icon: '🚪',
        description: 'Ремонт окремих кімнат та приміщень',
        services: [
          { id: 'kuhnya-remont', name: 'Ремонт кухні', description: 'Повний ремонт кухні з заміною сантехніки та електрики', basePrice: 25000, unit: 'за кімнату', priceFrom: true, popular: true },
          { id: 'vannaya-remont', name: 'Ремонт ванної кімнати', description: 'Ремонт санвузла під ключ', basePrice: 18000, unit: 'за кімнату', priceFrom: true, popular: true },
          { id: 'spalnya-remont', name: 'Ремонт спальні', description: 'Ремонт спальної кімнати', basePrice: 15000, unit: 'за кімнату', priceFrom: true },
          { id: 'gostinaya-remont', name: 'Ремонт вітальні', description: 'Ремонт вітальні кімнати', basePrice: 20000, unit: 'за кімнату', priceFrom: true },
        ]
      },
      {
        id: 'stroitelstvo',
        name: 'Будівництво',
        icon: '🏗️',
        description: 'Будівництво будинків, котеджів, гаражів',
        services: [
          { id: 'dom-karkasnyy', name: 'Каркасний будинок', description: 'Будівництво каркасного будинку', basePrice: 8000, unit: 'м²', priceFrom: true },
          { id: 'dom-kirpich', name: 'Цегляний будинок', description: 'Будівництво будинку з цегли', basePrice: 12000, unit: 'м²', priceFrom: true },
          { id: 'garazh', name: 'Гараж', description: 'Будівництво гаража', basePrice: 3500, unit: 'м²', priceFrom: true },
          { id: 'besedka', name: 'Альтанка/бесідка', description: 'Будівництво дерев\'яної альтанки', basePrice: 15000, unit: 'за об\'єкт', priceFrom: true },
        ]
      },
      {
        id: 'otdelochnye',
        name: 'Оздоблювальні роботи',
        icon: '🎨',
        description: 'Штукатурка, шпаклівка, фарбування, обої',
        services: [
          { id: 'shtukaturka', name: 'Штукатурка стін', description: 'Машинна та ручна штукатурка', basePrice: 280, unit: 'м²', priceFrom: true, popular: true },
          { id: 'shpaklevka', name: 'Шпаклівка стін', description: 'Шпаклівка під фарбування або обої', basePrice: 120, unit: 'м²', priceFrom: true },
          { id: 'pokraska', name: 'Фарбування стін', description: 'Фарбування стін та стель', basePrice: 80, unit: 'м²', priceFrom: true },
          { id: 'oboi', name: 'Поклейка шпалер', description: 'Поклейка шпалер всіх видів', basePrice: 100, unit: 'м²', priceFrom: true, popular: true },
        ]
      },
    ]
  },
  {
    id: 'santehnika',
    name: 'Сантехніка',
    icon: '🚿',
    description: 'Установка сантехніки, ремонт труб, системи опалення',
    subcategories: [
      {
        id: 'ustanovka-santehniki',
        name: 'Установка сантехніки',
        icon: '🚽',
        services: [
          { id: 'unitaz', name: 'Установка унітазу', description: 'Монтаж унітазу з підключенням', basePrice: 800, unit: 'за шт', priceFrom: true, popular: true },
          { id: 'rakovina', name: 'Установка раковини', description: 'Монтаж раковини/умивальника', basePrice: 600, unit: 'за шт', priceFrom: true },
          { id: 'vanna', name: 'Установка ванни', description: 'Монтаж ванни (акрил, чавун, сталь)', basePrice: 1500, unit: 'за шт', priceFrom: true, popular: true },
          { id: 'dush-kabina', name: 'Установка душової кабіни', description: 'Монтаж душової кабіни/боксу', basePrice: 2500, unit: 'за шт', priceFrom: true },
          { id: 'smesitel', name: 'Установка змішувача', description: 'Заміна/монтаж змішувача', basePrice: 400, unit: 'за шт', priceFrom: true },
        ]
      },
      {
        id: 'santeh-remont',
        name: 'Ремонт сантехніки',
        icon: '🔧',
        services: [
          { id: 'prochistka-kanalyzatsii', name: 'Прочистка каналізації', description: 'Чистка засмічень у трубах', basePrice: 500, unit: 'за точку', priceFrom: true, popular: true },
          { id: 'zamena-trub', name: 'Заміна труб', description: 'Заміна старих труб на нові', basePrice: 300, unit: 'м.п.', priceFrom: true },
          { id: 'ustranenie-techni', name: 'Усунення витоку', description: 'Пошук та усунення витоку води', basePrice: 400, unit: 'за роботу', priceFrom: true },
        ]
      },
      {
        id: 'otoplenie',
        name: 'Опалення',
        icon: '🔥',
        services: [
          { id: 'montazh-kotla', name: 'Монтаж котла', description: 'Установка газового/електро котла', basePrice: 3500, unit: 'за шт', priceFrom: true },
          { id: 'radiatory', name: 'Установка радіаторів', description: 'Монтаж батарей опалення', basePrice: 800, unit: 'за шт', priceFrom: true },
          { id: 'teplyy-pol', name: 'Тепла підлога', description: 'Монтаж електричної теплої підлоги', basePrice: 450, unit: 'м²', priceFrom: true },
        ]
      },
    ]
  },
  {
    id: 'elektrika',
    name: 'Електрика',
    icon: '⚡',
    description: 'Електромонтажні роботи, заміна проводки, установка розеток',
    subcategories: [
      {
        id: 'elektro-montazh',
        name: 'Електромонтаж',
        icon: '🔌',
        services: [
          { id: 'zamena-provodki', name: 'Заміна проводки', description: 'Повна або часткова заміна електропроводки', basePrice: 150, unit: 'м.п.', priceFrom: true, popular: true },
          { id: 'rozetka', name: 'Установка розетки', description: 'Монтаж/заміна розетки', basePrice: 150, unit: 'за шт', priceFrom: true },
          { id: 'vychyklyatel', name: 'Установка вимикача', description: 'Монтаж/заміна вимикача', basePrice: 150, unit: 'за шт', priceFrom: true },
          { id: 'lyustra', name: 'Установка люстри', description: 'Монтаж освітлювального приладу', basePrice: 300, unit: 'за шт', priceFrom: true, popular: true },
          { id: 'elektroshchit', name: 'Монтаж електрощита', description: 'Установка та підключення щита', basePrice: 1200, unit: 'за шт', priceFrom: true },
        ]
      },
      {
        id: 'elektro-remont',
        name: 'Ремонт електрики',
        icon: '🔧',
        services: [
          { id: 'diagnostyka', name: 'Діагностика електрики', description: 'Пошук несправностей у проводці', basePrice: 500, unit: 'за виїзд', priceFrom: true },
          { id: 'zamena-avtomata', name: 'Заміна автомата', description: 'Заміна запобіжника/автомата', basePrice: 200, unit: 'за шт', priceFrom: true },
        ]
      },
    ]
  },
  {
    id: 'uborka',
    name: 'Прибирання',
    icon: '🧹',
    description: 'Генеральне прибирання, прибирання після ремонту, миття вікон',
    subcategories: [
      {
        id: 'uborka-kvartiry',
        name: 'Прибирання квартири',
        icon: '🏠',
        services: [
          { id: 'podderzhivayushchaya', name: 'Підтримуюче прибирання', description: 'Регулярне прибирання квартири', basePrice: 800, unit: 'за кімнату', priceFrom: true, popular: true },
          { id: 'generalnaya', name: 'Генеральне прибирання', description: 'Глибоке прибирання всіх приміщень', basePrice: 1500, unit: 'за кімнату', priceFrom: true, popular: true },
          { id: 'posle-remonta', name: 'Прибирання після ремонту', description: 'Прибирання будівельного пилу та сміття', basePrice: 2500, unit: 'за кімнату', priceFrom: true },
        ]
      },
      {
        id: 'moyka',
        name: 'Миття',
        icon: '💧',
        services: [
          { id: 'moyka-okon', name: 'Миття вікон', description: 'Миття вікон з обох сторін', basePrice: 150, unit: 'за м²', priceFrom: true, popular: true },
          { id: 'moyka-balkona', name: 'Миття балкона', description: 'Миття вікон та рам на балконі', basePrice: 500, unit: 'за балкон', priceFrom: true },
        ]
      },
    ]
  },
  {
    id: 'gruzchiki',
    name: 'Вантажники та переїзди',
    icon: '📦',
    description: 'Вантажні роботи, переїзди, вивіз сміття',
    subcategories: [
      {
        id: 'gruzoperevozki',
        name: 'Вантажоперевезення',
        icon: '🚚',
        services: [
          { id: 'gruzchik-chas', name: 'Вантажник (погодинно)', description: 'Вантажник за годину роботи', basePrice: 250, unit: 'за год', priceFrom: true, popular: true },
          { id: 'pereezd-kvartira', name: 'Квартирний переїзд', description: 'Переїзд зі збором/розбором меблів', basePrice: 2500, unit: 'за переїзд', priceFrom: true },
          { id: 'pereezd-ofis', name: 'Офісний переїзд', description: 'Переїзд офісу з технікою', basePrice: 5000, unit: 'за переїзд', priceFrom: true },
        ]
      },
      {
        id: 'vyvoz-musora',
        name: 'Вивіз сміття',
        icon: '🗑️',
        services: [
          { id: 'vyvoz-stroymusora', name: 'Вивіз будівельного сміття', description: 'Вивіз сміття після ремонту', basePrice: 1500, unit: 'за рейс', priceFrom: true },
          { id: 'vyvoz-mebeli', name: 'Вивіз старих меблів', description: 'Вивезення та утилізація меблів', basePrice: 800, unit: 'за шт', priceFrom: true },
        ]
      },
    ]
  },
  {
    id: 'mebel',
    name: 'Меблі та збірка',
    icon: '🪑',
    description: 'Збірка меблів, ремонт меблів, виготовлення на замовлення',
    subcategories: [
      {
        id: 'sborka-mebeli',
        name: 'Збірка меблів',
        icon: '🔧',
        services: [
          { id: 'sborka-shkaf', name: 'Збірка шафи', description: 'Збірка шафи-купе або розпашної', basePrice: 800, unit: 'за шт', priceFrom: true, popular: true },
          { id: 'sborka-krovat', name: 'Збірка ліжка', description: 'Збірка ліжка з матрацом', basePrice: 500, unit: 'за шт', priceFrom: true },
          { id: 'sborka-stol', name: 'Збірка столу', description: 'Збірка обіднього/письмового столу', basePrice: 400, unit: 'за шт', priceFrom: true },
          { id: 'sborka-komod', name: 'Збірка комода', description: 'Збірка комода/тумби', basePrice: 350, unit: 'за шт', priceFrom: true },
          { id: 'sborka-kuhnya', name: 'Збірка кухні', description: 'Збірка кухонного гарнітура', basePrice: 2500, unit: 'за комплект', priceFrom: true, popular: true },
        ]
      },
    ]
  },
  {
    id: 'sad',
    name: 'Сад та город',
    icon: '🌳',
    description: 'Догляд за садом, обрізка дерев, покос трави',
    subcategories: [
      {
        id: 'uhod-sad',
        name: 'Догляд за садом',
        icon: '🌿',
        services: [
          { id: 'pokos-travy', name: 'Покіс трави', description: 'Стрижка газону триммером/газонокосаркою', basePrice: 80, unit: 'за сотку', priceFrom: true, popular: true },
          { id: 'obrezka-dereviev', name: 'Обрізка дерев', description: 'Обрізка плодових та декоративних дерев', basePrice: 500, unit: 'за дерево', priceFrom: true },
          { id: 'uborka-listev', name: 'Прибирання листя', description: 'Збір та вивіз опалого листя', basePrice: 300, unit: 'за сотку', priceFrom: true },
        ]
      },
    ]
  },
];

// Прайс-таблицы для разных категорий
export const priceTables: Record<string, PriceTable[]> = {
  'remont-kvartiry': [
    {
      id: 'kosmeticheskiy-prices',
      name: 'Косметичний ремонт - детальний прайс',
      description: 'Ціни на окремі види робіт при косметичному ремонті',
      columns: ['Вид роботи', 'Одиниця', 'Ціна від, грн'],
      rows: [
        { service: 'Фарбування стін', prices: ['м²', '60'] },
        { service: 'Фарбування стелі', prices: ['м²', '80'] },
        { service: 'Поклейка шпалер (паперові)', prices: ['м²', '80'] },
        { service: 'Поклейка шпалер (вінілові/флізелін)', prices: ['м²', '100'] },
        { service: 'Укладання ламінату', prices: ['м²', '120'] },
        { service: 'Укладання лінолеуму', prices: ['м²', '80'] },
        { service: 'Заміна плінтуса', prices: ['м.п.', '40'] },
        { service: 'Установка дверей', prices: ['за шт', '800'] },
      ]
    },
    {
      id: 'kapitalnyy-prices',
      name: 'Капітальний ремонт - детальний прайс',
      description: 'Ціни на окремі види робіт при капітальному ремонті',
      columns: ['Вид роботи', 'Одиниця', 'Ціна від, грн'],
      rows: [
        { service: 'Демонтаж стін', prices: ['м²', '150'] },
        { service: 'Демонтаж підлоги', prices: ['м²', '80'] },
        { service: 'Демонтаж стелі', prices: ['м²', '100'] },
        { service: 'Штукатурка стін', prices: ['м²', '280'] },
        { service: 'Штукатурка стелі', prices: ['м²', '350'] },
        { service: 'Стяжка підлоги', prices: ['м²', '180'] },
        { service: 'Електропроводка (нова)', prices: ['м.п.', '150'] },
        { service: 'Заміна труб водопостачання', prices: ['м.п.', '300'] },
        { service: 'Укладання плитки (стіни)', prices: ['м²', '450'] },
        { service: 'Укладання плитки (підлога)', prices: ['м²', '400'] },
      ]
    }
  ],
  'santehnika': [
    {
      id: 'santeh-prices',
      name: 'Прайс на сантехнічні роботи',
      description: 'Вартість установки та заміни сантехніки',
      columns: ['Послуга', 'Одиниця', 'Ціна від, грн'],
      rows: [
        { service: 'Установка унітазу (навісний)', prices: ['за шт', '1000'] },
        { service: 'Установка унітазу (компакт)', prices: ['за шт', '800'] },
        { service: 'Установка інсталяції', prices: ['за шт', '1500'] },
        { service: 'Установка раковини (тюльпан)', prices: ['за шт', '600'] },
        { service: 'Установка раковини (підвісна)', prices: ['за шт', '800'] },
        { service: 'Установка ванни (акрил)', prices: ['за шт', '1500'] },
        { service: 'Установка ванни (чавун)', prices: ['за шт', '2000'] },
        { service: 'Установка душової кабіни', prices: ['за шт', '2500'] },
        { service: 'Установка змішувача', prices: ['за шт', '400'] },
        { service: 'Установка бойлера', prices: ['за шт', '1200'] },
        { service: 'Прочистка каналізації', prices: ['за точку', '500'] },
      ]
    }
  ],
  'elektrika': [
    {
      id: 'elektro-prices',
      name: 'Прайс на електромонтажні роботи',
      description: 'Вартість електромонтажних робіт',
      columns: ['Послуга', 'Одиниця', 'Ціна від, грн'],
      rows: [
        { service: 'Штроблення стін під проводку', prices: ['м.п.', '50'] },
        { service: 'Прокладання кабелю', prices: ['м.п.', '30'] },
        { service: 'Установка розетки/вимикача', prices: ['за шт', '150'] },
        { service: 'Установка розетки (з штробленням)', prices: ['за шт', '300'] },
        { service: 'Установка люстри (проста)', prices: ['за шт', '300'] },
        { service: 'Установка люстри (складна)', prices: ['за шт', '600'] },
        { service: 'Установка світильника точкового', prices: ['за шт', '200'] },
        { service: 'Монтаж електрощита', prices: ['за шт', '1200'] },
        { service: 'Установка автомата', prices: ['за шт', '200'] },
        { service: 'Заміна проводки (квартира 1-кімн)', prices: ['за об\'єкт', '8000'] },
      ]
    }
  ],
};

// Заказы/задания
export interface Order {
  id: number;
  title: string;
  description: string;
  category: string;
  subcategory: string;
  service: string;
  address: string;
  date: string;
  time: string;
  budget: string;
  status: 'new' | 'in_progress' | 'completed' | 'cancelled';
  createdAt: string;
  responses: number;
}

export const orders: Order[] = [
  {
    id: 1,
    title: 'Косметичний ремонт кухні 12 м²',
    description: 'Потрібно пофарбувати стелі та стіни, покласти новий ламінат, замінити плінтус. Матеріали є.',
    category: 'remont',
    subcategory: 'remont-komnaty',
    service: 'kuhnya-remont',
    address: 'Київ, Оболонський район, вул. Героїв Дніпра',
    date: '2026-02-20',
    time: '10:00',
    budget: '25000',
    status: 'new',
    createdAt: '2 години тому',
    responses: 3,
  },
  {
    id: 2,
    title: 'Установка унітазу та раковини',
    description: 'Потрібно встановити новий унітаз з інсталяцією та підвісну раковину. Стару сантехніку потрібно демонтувати.',
    category: 'santehnika',
    subcategory: 'ustanovka-santehniki',
    service: 'unitaz',
    address: 'Київ, Печерський район, бульвар Лесі Українки',
    date: '2026-02-15',
    time: '14:00',
    budget: '3000',
    status: 'in_progress',
    createdAt: '5 годин тому',
    responses: 2,
  },
  {
    id: 3,
    title: 'Генеральне прибирання 3-кімнатної квартири',
    description: 'Потрібно прибрати квартиру після орендарів. Миття вікон, чищення санвузлів, прибирання кухні.',
    category: 'uborka',
    subcategory: 'uborka-kvartiry',
    service: 'generalnaya',
    address: 'Київ, Голосіївський район, проспект Науки',
    date: '2026-02-14',
    time: '09:00',
    budget: '4500',
    status: 'new',
    createdAt: '1 день тому',
    responses: 5,
  },
  {
    id: 4,
    title: 'Збірка кухонного гарнітура',
    description: 'Потрібно зібрати кухню ІКЕА (8 модулів), встановити стільницю та навісити шафки.',
    category: 'mebel',
    subcategory: 'sborka-mebeli',
    service: 'sborka-kuhnya',
    address: 'Київ, Дарницький район, вул. Драгоманова',
    date: '2026-02-18',
    time: '11:00',
    budget: '3500',
    status: 'new',
    createdAt: '2 дні тому',
    responses: 4,
  },
];

// Популярные услуги для главной
export const popularServices = [
  { name: 'Косметичний ремонт', icon: '🎨', category: 'remont' },
  { name: 'Установка унітазу', icon: '🚽', category: 'santehnika' },
  { name: 'Миття вікон', icon: '🪟', category: 'uborka' },
  { name: 'Збірка меблів', icon: '🪑', category: 'mebel' },
  { name: 'Заміна розетки', icon: '🔌', category: 'elektrika' },
  { name: 'Вантажник', icon: '📦', category: 'gruzchiki' },
  { name: 'Покіс трави', icon: '🌿', category: 'sad' },
  { name: 'Прочистка каналізації', icon: '🔧', category: 'santehnika' },
];

// Навигация для сайдбара
export const sidebarNav = [
  { id: 'home', name: 'Головна', icon: '🏠' },
  { id: 'categories', name: 'Всі послуги', icon: '📋' },
  { id: 'orders', name: 'Завдання', icon: '📦' },
  { id: 'my-orders', name: 'Мої замовлення', icon: '📁' },
  { id: 'how-it-works', name: 'Як це працює', icon: '❓' },
  { id: 'faq', name: 'Допомога', icon: '💬' },
];
