import { Tag, ArrowRight } from 'lucide-react';

interface PricesPageProps {
  onPageChange: (page: string, params?: any) => void;
}

export function PricesPage({ onPageChange }: PricesPageProps) {
  const priceCategories = [
    { name: 'Ремонт квартири', minPrice: 'від 3 500 грн/м²', icon: '🏠' },
    { name: 'Будівництво будинку', minPrice: 'від 8 000 грн/м²', icon: '🏡' },
    { name: 'Плиточні роботи', minPrice: 'від 450 грн/м²', icon: '🔲' },
    { name: 'Малярні роботи', minPrice: 'від 120 грн/м²', icon: '🎨' },
    { name: 'Штукатурні роботи', minPrice: 'від 280 грн/м²', icon: '🧱' },
    { name: 'Монтаж гіпсокартону', minPrice: 'від 180 грн/м²', icon: '📋' },
    { name: 'Поклейка шпалер', minPrice: 'від 80 грн/м²', icon: '📜' },
    { name: 'Покриття для підлоги', minPrice: 'від 150 грн/м²', icon: '🪵' },
    { name: 'Стеля', minPrice: 'від 200 грн/м²', icon: '⬜' },
    { name: 'Покрівельні роботи', minPrice: 'від 550 грн/м²', icon: '🏚️' },
    { name: 'Електромонтажні роботи', minPrice: 'від 150 грн/точка', icon: '⚡' },
    { name: 'Сантехнічні роботи', minPrice: 'від 400 грн/точка', icon: '🚿' },
  ];

  return (
    <div className="min-h-screen bg-light">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Розцінки на будівельні роботи</h1>
          <p className="text-gray-600 mt-2">Актуальні ціни на ремонт та будівництво в Україні</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-lg shadow-sm p-6 text-center">
            <div className="text-4xl font-bold text-[#5b9bd5]">50 000+</div>
            <div className="text-gray-600 mt-2">Прайс-листів майстрів</div>
          </div>
          <div className="bg-white rounded-lg shadow-sm p-6 text-center">
            <div className="text-4xl font-bold text-[#5b9bd5]">1 361</div>
            <div className="text-gray-600 mt-2">Категорій робіт</div>
          </div>
          <div className="bg-white rounded-lg shadow-sm p-6 text-center">
            <div className="text-4xl font-bold text-[#5b9bd5]">Щогодини</div>
            <div className="text-gray-600 mt-2">Оновлення цін</div>
          </div>
        </div>

        {/* Price categories */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-xl font-bold mb-6">Категорії робіт та розцінки</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {priceCategories.map((cat, idx) => (
              <div 
                key={idx} 
                className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => onPageChange('workers')}
              >
                <div className="flex items-start gap-3">
                  <div className="text-3xl">{cat.icon}</div>
                  <div className="flex-1">
                    <h3 className="font-medium text-[#5b9bd5] hover:underline">{cat.name}</h3>
                    <p className="text-sm text-gray-500 mt-1">{cat.minPrice}</p>
                  </div>
                  <ArrowRight size={18} className="text-gray-400" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Info section */}
        <div className="bg-white rounded-lg shadow-sm p-6 mt-6">
          <h2 className="text-xl font-bold mb-4">Як формуються ціни?</h2>
          <div className="prose max-w-none text-gray-700">
            <p className="mb-4">
              Ціни на будівельні роботи формуються на основі прайс-листів, які надають майстри 
              та будівельні компанії. Ми аналізуємо ціни щогодини та оновлюємо середні значення 
              по кожній категорії робіт.
            </p>
            <p className="mb-4">
              Зверніть увагу, що вказані ціни є орієнтовними. Остаточна вартість робіт залежить 
              від багатьох факторів: складності робіт, термінів виконання, регіону, наявності 
              матеріалів та інших умов.
            </p>
            <p>
              Для отримання точної вартості рекомендуємо створити тендер на нашому сайті. 
              Майстри самі зв'яжуться з вами та запропонують свої ціни.
            </p>
          </div>
          
          <div className="mt-6">
            <button 
              onClick={() => onPageChange('tenders')}
              className="btn-orange text-white px-6 py-3 rounded inline-flex items-center gap-2 hover:bg-[#e06015] transition-colors"
            >
              <Tag size={18} />
              <span>Створити тендер</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
