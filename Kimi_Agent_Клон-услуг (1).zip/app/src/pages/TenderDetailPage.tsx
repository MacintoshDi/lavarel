import { tenders } from '@/data/mockData';
import { ArrowLeft, MapPin, Phone, Mail, Calendar, User, Briefcase, BarChart3, Clock, CheckCircle } from 'lucide-react';

interface TenderDetailPageProps {
  tenderId: number;
  onPageChange: (page: string, params?: any) => void;
}

export function TenderDetailPage({ tenderId, onPageChange }: TenderDetailPageProps) {
  const tender = tenders.find(t => t.id === tenderId);

  if (!tender) {
    return (
      <div className="min-h-screen bg-light flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Тендер не знайдено</h1>
          <button 
            onClick={() => onPageChange('tenders')}
            className="text-[#5b9bd5] hover:underline"
          >
            Повернутися до списку тендерів
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-light">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center gap-2 text-sm">
            <button 
              onClick={() => onPageChange('tenders')}
              className="text-[#5b9bd5] hover:underline"
            >
              Всі замовлення
            </button>
            <span className="text-gray-400">/</span>
            <span className="text-gray-600">Тендер №{tender.id}</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex gap-8">
          {/* Main content */}
          <div className="flex-1">
            {/* Tender header */}
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="bg-[#5b9bd5] text-white px-6 py-3 flex items-center gap-4">
                <span className="bg-white/20 px-3 py-1 rounded text-sm">№{tender.id}</span>
                <span className="flex items-center gap-2">
                  <CheckCircle size={16} />
                  Тендер відкритий для пропозицій
                </span>
              </div>
              
              <div className="p-6">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-[#5b9bd5] rounded flex items-center justify-center">
                      <Briefcase className="text-white" size={32} />
                    </div>
                    <div>
                      <h1 className="text-xl font-bold">{tender.title}</h1>
                      <p className="text-gray-500 text-sm mt-1">{tender.category}</p>
                    </div>
                  </div>
                  {tender.isTop && (
                    <span className="top-badge flex items-center gap-1">
                      <span>★</span> ТОП
                    </span>
                  )}
                </div>

                <div className="prose max-w-none">
                  <p className="text-gray-700 whitespace-pre-line">{tender.description}</p>
                </div>

                {tender.details && (
                  <div className="mt-6 space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <span className="text-gray-500 text-sm">Об'єкт:</span>
                        <p className="font-medium">{tender.details.object}</p>
                      </div>
                      <div>
                        <span className="text-gray-500 text-sm">Площа:</span>
                        <p className="font-medium">{tender.details.area}</p>
                      </div>
                      <div>
                        <span className="text-gray-500 text-sm">Місцезнаходження:</span>
                        <p className="font-medium">{tender.details.location}</p>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-bold mb-2">Обсяг робіт:</h3>
                      <ul className="list-disc list-inside space-y-1">
                        {tender.details.workScope.map((item, idx) => (
                          <li key={idx} className="text-gray-700">{item}</li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h3 className="font-bold mb-2">Умови:</h3>
                      <ul className="list-disc list-inside space-y-1">
                        {tender.details.conditions.map((item, idx) => (
                          <li key={idx} className="text-gray-700">{item}</li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h3 className="font-bold mb-2">Вимоги до виконавців:</h3>
                      <ul className="list-disc list-inside space-y-1">
                        {tender.details.requirements.map((item, idx) => (
                          <li key={idx} className="text-gray-700">{item}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-yellow-50 border border-yellow-200 rounded p-4 mt-4">
                      <p className="text-sm text-gray-700">
                        <span className="font-bold">👉 У відгуку прохання зазначати:</span>
                        <br />
                        • ціну за кв.м
                        <br />
                        • фото виконаних робіт
                      </p>
                    </div>
                  </div>
                )}

                <div className="mt-6 pt-6 border-t flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <BarChart3 size={18} className="text-gray-500" />
                    <span className="font-bold">Бюджет {tender.budget}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-500">
                    <User size={18} />
                    <span>Власник</span>
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-4 text-sm text-gray-500">
                  <div className="flex items-center gap-2">
                    <Calendar size={16} />
                    <span>Можна почати {tender.details?.startDate}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock size={16} />
                    <span>Потрібно закінчити до {tender.details?.endDate}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Responses section */}
            <div className="bg-white rounded-lg shadow-sm p-6 mt-4">
              <h2 className="text-lg font-bold mb-4">Пропозиції по тендеру (4)</h2>
              
              <div className="border rounded-lg p-4">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                    <User size={24} className="text-gray-500" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold">Бригада "ФОП РУСТАМОВ ІСА"</span>
                      <span className="text-sm text-gray-500">Рейтинг: 40 з 80</span>
                    </div>
                    <p className="text-gray-600 text-sm mt-2">
                      На сайті вже 4 місяці тому
                      <br />
                      Був 5 годин тому
                    </p>
                    <p className="text-gray-700 mt-2">
                      Маємо великий досвід. Якраз саме зараз накриваємо три пташники розміром 120х18м. 
                      Можу по відео показати як мої люди працюють
                    </p>
                    <p className="text-sm text-gray-500 mt-2">11 днів тому</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar - Owner info */}
          <div className="w-80 flex-shrink-0">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="text-center">
                <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
                  <User size={40} className="text-gray-500" />
                </div>
                <h3 className="font-bold text-lg">{tender.owner.name.toUpperCase()}</h3>
                <p className="text-sm text-gray-500 mt-1">Зареєстрований {tender.owner.registered}</p>
                <p className="text-sm text-gray-500">Був на сайті {tender.owner.lastSeen}</p>
              </div>

              <div className="mt-6 space-y-3">
                <div className="flex items-center gap-2 text-gray-600">
                  <MapPin size={18} />
                  <span>{tender.location} (Київська область)</span>
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <Phone size={18} />
                  <span>{tender.owner.phone}</span>
                </div>
              </div>

              <div className="mt-6 space-y-3">
                <button className="w-full text-[#5b9bd5] hover:underline text-sm">
                  Показати номер
                </button>
                <button className="w-full bg-[#5b9bd5] text-white py-2 rounded flex items-center justify-center gap-2 hover:bg-[#4a8ac4] transition-colors">
                  <Mail size={18} />
                  <span>Особисте повідомлення</span>
                </button>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-4 mt-4">
              <button 
                onClick={() => onPageChange('tenders')}
                className="flex items-center gap-2 text-[#5b9bd5] hover:underline"
              >
                <ArrowLeft size={18} />
                <span>Повернутися до списку</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
