import { useState } from 'react';
import { ChevronDown, ChevronUp, Phone, Mail, MessageCircle } from 'lucide-react';

interface FAQPageProps {
  onPageChange: (page: string, params?: any) => void;
}

export function FAQPage({  }: FAQPageProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: 'Як створити завдання?',
      answer: 'Для створення завдання натисніть кнопку "Створити завдання", оберіть потрібну категорію послуги, заповніть опис завдання, вкажіть адресу, дату та бюджет. Після публікації виконавці зможуть залишати свої пропозиції.'
    },
    {
      question: 'Скільки коштує створення завдання?',
      answer: 'Створення завдання на платформі повністю безкоштовне. Ви платите лише за виконану роботу безпосередньо виконавцю.'
    },
    {
      question: 'Як обрати виконавця?',
      answer: 'Після публікації завдання ви отримаєте пропозиції від виконавців. Порівняйте їх ціни, відгуки, рейтинг та портфоліо. Оберіть найкращий варіант та зв\'яжіться з виконавцем.'
    },
    {
      question: 'Чи безпечно замовляти послуги через сайт?',
      answer: 'Так, ми перевіряємо всіх виконавців перед реєстрацією. Також ви можете переглянути відгуки інших клієнтів та рейтинг виконавця перед вибором.'
    },
    {
      question: 'Як оплачується робота?',
      answer: 'Оплата здійснюється безпосередньо виконавцю після завершення роботи. Ми рекомендуємо укладати договір та не передавати повну передоплату до початку робіт.'
    },
    {
      question: 'Що робити, якщо виконавець не якісно виконав роботу?',
      answer: 'У разі виникнення проблем зверніться до нашої служби підтримки. Ми допоможемо вирішити конфлікт та за необхідності заблокуємо недобросовісного виконавця.'
    },
    {
      question: 'Чи можу я скасувати завдання?',
      answer: 'Так, ви можете скасувати завдання до моменту підтвердження виконавцем. Після початку роботи скасування можливе за домовленістю з виконавцем.'
    },
    {
      question: 'Як змінити дані в завданні після публікації?',
      answer: 'Ви можете редагувати завдання в особистому кабінеті. Якщо робота вже розпочата, обговоріть зміни з виконавцем.'
    },
  ];

  return (
    <div className="space-y-6 pb-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-800">Допомога (FAQ)</h1>
        <p className="text-gray-500">Відповіді на найпоширеніші питання</p>
      </div>

      {/* Contact cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-5 card-shadow text-center">
          <div className="w-12 h-12 bg-[#8B5CF6]/10 rounded-xl flex items-center justify-center mx-auto mb-3">
            <Phone className="text-[#8B5CF6]" size={22} />
          </div>
          <h3 className="font-semibold text-gray-800 mb-1">Телефон</h3>
          <p className="text-gray-600 text-sm">0 800 123 456</p>
          <p className="text-xs text-gray-400">Безкоштовно</p>
        </div>
        <div className="bg-white rounded-xl p-5 card-shadow text-center">
          <div className="w-12 h-12 bg-[#8B5CF6]/10 rounded-xl flex items-center justify-center mx-auto mb-3">
            <Mail className="text-[#8B5CF6]" size={22} />
          </div>
          <h3 className="font-semibold text-gray-800 mb-1">Email</h3>
          <p className="text-gray-600 text-sm">support@servis.ua</p>
          <p className="text-xs text-gray-400">24/7</p>
        </div>
        <div className="bg-white rounded-xl p-5 card-shadow text-center">
          <div className="w-12 h-12 bg-[#8B5CF6]/10 rounded-xl flex items-center justify-center mx-auto mb-3">
            <MessageCircle className="text-[#8B5CF6]" size={22} />
          </div>
          <h3 className="font-semibold text-gray-800 mb-1">Чат</h3>
          <p className="text-gray-600 text-sm">Онлайн підтримка</p>
          <p className="text-xs text-gray-400">Пн-Пт 9:00-18:00</p>
        </div>
      </div>

      {/* FAQ */}
      <div className="bg-white rounded-xl card-shadow overflow-hidden">
        <div className="p-5 border-b border-gray-100 bg-gray-50">
          <h2 className="font-semibold text-gray-800">Часті питання</h2>
        </div>
        <div className="divide-y divide-gray-100">
          {faqs.map((faq, idx) => (
            <div key={idx} className="border-b border-gray-100 last:border-0">
              <button
                onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
                className="w-full flex items-center justify-between p-5 text-left hover:bg-gray-50 transition-colors"
              >
                <span className="font-medium text-gray-800 pr-4">{faq.question}</span>
                {openIndex === idx ? (
                  <ChevronUp size={18} className="text-gray-400 flex-shrink-0" />
                ) : (
                  <ChevronDown size={18} className="text-gray-400 flex-shrink-0" />
                )}
              </button>
              {openIndex === idx && (
                <div className="px-5 pb-5">
                  <p className="text-gray-600 text-sm">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
