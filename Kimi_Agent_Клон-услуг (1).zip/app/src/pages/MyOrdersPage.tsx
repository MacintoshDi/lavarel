import { useState } from 'react';
import { orders } from '@/data/servicesData';
import { Search, Eye, MessageSquare, Phone, Calendar, MapPin, Clock, CheckCircle, Clock3 } from 'lucide-react';

interface MyOrdersPageProps {
  onPageChange: (page: string, params?: any) => void;
}

export function MyOrdersPage({ onPageChange }: MyOrdersPageProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'new' | 'in_progress' | 'completed'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredOrders = orders.filter(order => {
    if (activeTab !== 'all' && order.status !== activeTab) return false;
    if (searchQuery && !order.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'new':
        return (
          <span className="inline-flex items-center gap-1.5 bg-blue-50 text-blue-600 px-2.5 py-1 rounded-full text-xs font-medium">
            <Clock3 size={12} /> Нове
          </span>
        );
      case 'in_progress':
        return (
          <span className="inline-flex items-center gap-1.5 bg-yellow-50 text-yellow-600 px-2.5 py-1 rounded-full text-xs font-medium">
            <Clock size={12} /> В роботі
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1.5 bg-green-50 text-green-600 px-2.5 py-1 rounded-full text-xs font-medium">
            <CheckCircle size={12} /> Виконано
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6 pb-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-800">Мої замовлення</h1>
        <p className="text-gray-500">Керуйте своїми завданнями та відстежуйте статус</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 card-shadow">
          <div className="text-2xl font-bold text-[#8B5CF6]">{orders.length}</div>
          <div className="text-gray-500 text-sm">Всього завдань</div>
        </div>
        <div className="bg-white rounded-xl p-4 card-shadow">
          <div className="text-2xl font-bold text-blue-500">{orders.filter(o => o.status === 'new').length}</div>
          <div className="text-gray-500 text-sm">Нових</div>
        </div>
        <div className="bg-white rounded-xl p-4 card-shadow">
          <div className="text-2xl font-bold text-yellow-500">{orders.filter(o => o.status === 'in_progress').length}</div>
          <div className="text-gray-500 text-sm">В роботі</div>
        </div>
        <div className="bg-white rounded-xl p-4 card-shadow">
          <div className="text-2xl font-bold text-green-500">{orders.filter(o => o.status === 'completed').length}</div>
          <div className="text-gray-500 text-sm">Виконано</div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl card-shadow p-4">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Tabs */}
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'all', label: 'Всі', count: orders.length },
              { id: 'new', label: 'Нові', count: orders.filter(o => o.status === 'new').length },
              { id: 'in_progress', label: 'В роботі', count: orders.filter(o => o.status === 'in_progress').length },
              { id: 'completed', label: 'Виконані', count: orders.filter(o => o.status === 'completed').length },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? 'bg-[#8B5CF6] text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {tab.label} ({tab.count})
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input
              type="text"
              placeholder="Пошук завдань..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-xl focus:border-[#8B5CF6] transition-colors"
            />
          </div>

          {/* Create button */}
          <button 
            onClick={() => onPageChange('create-order')}
            className="bg-[#8B5CF6] text-white px-4 py-2 rounded-xl hover:bg-[#7C3AED] transition-colors whitespace-nowrap text-sm font-medium"
          >
            + Нове завдання
          </button>
        </div>
      </div>

      {/* Orders list */}
      <div className="space-y-4">
        {filteredOrders.length === 0 ? (
          <div className="bg-white rounded-xl card-shadow p-12 text-center">
            <div className="text-5xl mb-4">📋</div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Немає завдань</h3>
            <p className="text-gray-500 mb-6">У вас ще немає завдань у цій категорії</p>
            <button 
              onClick={() => onPageChange('create-order')}
              className="bg-[#8B5CF6] text-white px-6 py-2.5 rounded-xl hover:bg-[#7C3AED] transition-colors"
            >
              Створити перше завдання
            </button>
          </div>
        ) : (
          filteredOrders.map((order) => (
            <div key={order.id} className="bg-white rounded-xl card-shadow p-5">
              <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    {getStatusBadge(order.status)}
                    <span className="text-gray-400 text-xs">№{order.id}</span>
                    <span className="text-gray-400 text-xs">{order.createdAt}</span>
                  </div>
                  <h3 className="font-semibold text-gray-800 mb-2">{order.title}</h3>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">{order.description}</p>
                  
                  <div className="flex flex-wrap gap-4 text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                      <MapPin size={12} /> {order.address}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar size={12} /> {order.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock size={12} /> {order.time}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col items-start lg:items-end gap-2">
                  <div className="text-xl font-bold text-[#8B5CF6]">
                    {order.budget} <span className="text-sm">грн</span>
                  </div>
                  <div className="text-xs text-gray-500">
                    {order.responses} пропозицій
                  </div>
                  <div className="flex gap-2 mt-2">
                    <button className="p-2 border border-gray-200 rounded-lg hover:border-[#8B5CF6] hover:text-[#8B5CF6] transition-colors">
                      <Eye size={16} />
                    </button>
                    <button className="p-2 border border-gray-200 rounded-lg hover:border-[#8B5CF6] hover:text-[#8B5CF6] transition-colors">
                      <MessageSquare size={16} />
                    </button>
                    <button className="p-2 bg-[#8B5CF6] text-white rounded-lg hover:bg-[#7C3AED] transition-colors">
                      <Phone size={16} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
