import { Users, Briefcase, Award, Target, Shield, Clock } from 'lucide-react';

interface AboutPageProps {
  onPageChange: (page: string, params?: any) => void;
}

export function AboutPage({ onPageChange }: AboutPageProps) {
  const features = [
    {
      icon: Users,
      title: '100 000+ майстрів',
      description: 'Велика база перевірених будівельників та компаній по всій Україні'
    },
    {
      icon: Briefcase,
      title: '175 000+ замовлень',
      description: 'Успішно виконаних тендерів та завершених проектів'
    },
    {
      icon: Award,
      title: 'Рейтингова система',
      description: 'Об\'єктивні оцінки та відгуки про роботу майстрів'
    },
    {
      icon: Target,
      title: 'Точні розцінки',
      description: 'Актуальні ціни на будівельні роботи, оновлюються щогодини'
    },
    {
      icon: Shield,
      title: 'Безпека',
      description: 'Перевірка користувачів та захист персональних даних'
    },
    {
      icon: Clock,
      title: '24/7 підтримка',
      description: 'Завжди на зв\'язку для вирішення ваших питань'
    },
  ];

  return (
    <div className="min-h-screen bg-light">
      {/* Header */}
      <div className="bg-[#2e5c8a] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">Про проект Rabotniki.UA</h1>
          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            Сервіс пошуку майстрів для ремонту та будівництва №1 в Україні
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Mission */}
        <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
          <h2 className="text-2xl font-bold mb-4">Наша місія</h2>
          <p className="text-gray-700 text-lg leading-relaxed">
            Ми створили Rabotniki.UA, щоб зробити пошук надійних будівельників простим і безпечним. 
            Наша мета — з'єднувати замовників з кваліфікованими майстрами, забезпечуючи прозорість 
            цін, якість робіт та захист інтересів обох сторін.
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div key={idx} className="bg-white rounded-lg shadow-sm p-6">
                <div className="w-12 h-12 bg-[#5b9bd5]/10 rounded-lg flex items-center justify-center mb-4">
                  <Icon className="text-[#5b9bd5]" size={24} />
                </div>
                <h3 className="font-bold text-lg mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            );
          })}
        </div>

        {/* How it works */}
        <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
          <h2 className="text-2xl font-bold mb-6">Як працює сервіс</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-bold text-[#5b9bd5] mb-4">Для замовників</h3>
              <ol className="space-y-3">
                <li className="flex items-start gap-3">
                  <span className="w-8 h-8 bg-[#5b9bd5] text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">1</span>
                  <span className="text-gray-700">Зареєструйтесь на сайті</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-8 h-8 bg-[#5b9bd5] text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">2</span>
                  <span className="text-gray-700">Створіть тендер з описом робіт</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-8 h-8 bg-[#5b9bd5] text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">3</span>
                  <span className="text-gray-700">Отримуйте пропозиції від майстрів</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-8 h-8 bg-[#5b9bd5] text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">4</span>
                  <span className="text-gray-700">Оберіть найкращу пропозицію</span>
                </li>
              </ol>
            </div>
            <div>
              <h3 className="text-xl font-bold text-[#5b9bd5] mb-4">Для майстрів</h3>
              <ol className="space-y-3">
                <li className="flex items-start gap-3">
                  <span className="w-8 h-8 bg-[#f37021] text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">1</span>
                  <span className="text-gray-700">Зареєструйтесь як майстер</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-8 h-8 bg-[#f37021] text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">2</span>
                  <span className="text-gray-700">Заповніть профіль та портфоліо</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-8 h-8 bg-[#f37021] text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">3</span>
                  <span className="text-gray-700">Знаходьте актуальні тендери</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="w-8 h-8 bg-[#f37021] text-white rounded-full flex items-center justify-center flex-shrink-0 font-bold">4</span>
                  <span className="text-gray-700">Залишайте пропозиції та отримуйте замовлення</span>
                </li>
              </ol>
            </div>
          </div>
        </div>

        {/* History */}
        <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
          <h2 className="text-2xl font-bold mb-4">Історія проекту</h2>
          <div className="space-y-4 text-gray-700">
            <p>
              Проект Rabotniki.UA був запущений у 2015 році з метою допомогти українцям знаходити 
              надійних будівельників для ремонту та будівництва. За роки роботи ми стали найбільшим 
              сервісом у своїй ніші в Україні.
            </p>
            <p>
              Сьогодні наша платформа об'єднує понад 100 000 майстрів та будівельних компаній, 
              а кількість успішно виконаних замовлень перевищила 175 000.
            </p>
            <p>
              Ми постійно вдосконалюємо сервіс, додаючи нові функції та інструменти для зручності 
              наших користувачів. Наш будівельний калькулятор, система тендерів та рейтингова система 
              стали незамінними помічниками для тисяч українців.
            </p>
          </div>
        </div>

        {/* CTA */}
        <div className="bg-[#2e5c8a] rounded-lg p-8 text-center text-white">
          <h2 className="text-2xl font-bold mb-4">Приєднуйтесь до нас!</h2>
          <p className="text-white/80 mb-6 max-w-xl mx-auto">
            Зареєструйтесь прямо зараз та отримайте доступ до всіх можливостей сервісу
          </p>
          <div className="flex gap-4 justify-center">
            <button 
              onClick={() => onPageChange('signup')}
              className="btn-orange text-white px-8 py-3 rounded-lg font-medium hover:bg-[#e06015] transition-colors"
            >
              Зареєструватися
            </button>
            <button 
              onClick={() => onPageChange('faq')}
              className="bg-white text-[#2e5c8a] px-8 py-3 rounded-lg font-medium hover:bg-gray-100 transition-colors"
            >
              Дізнатися більше
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
