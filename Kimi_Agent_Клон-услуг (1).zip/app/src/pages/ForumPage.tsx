import { MessageSquare, Users, MessageCircle, TrendingUp } from 'lucide-react';

interface ForumPageProps {
  onPageChange: (page: string, params?: any) => void;
}

export function ForumPage({  }: ForumPageProps) {
  const forumSections = [
    {
      title: 'Ремонт квартири',
      topics: 1245,
      posts: 8932,
      lastTopic: 'Як вибрати шпалери для вітальні?',
      lastAuthor: 'Олена К.',
      lastTime: '2 години тому',
    },
    {
      title: 'Будівництво будинку',
      topics: 892,
      posts: 5671,
      lastTopic: 'Фундамент на пучинистих ґрунтах',
      lastAuthor: 'Іван М.',
      lastTime: '5 годин тому',
    },
    {
      title: 'Електрика',
      topics: 678,
      posts: 4234,
      lastTopic: 'Проводка в квартирі - поради',
      lastAuthor: 'Сергій П.',
      lastTime: 'вчора',
    },
    {
      title: 'Сантехніка',
      topics: 543,
      posts: 3456,
      lastTopic: 'Вибір котла опалення',
      lastAuthor: 'Андрій В.',
      lastTime: '2 дні тому',
    },
    {
      title: 'Плиточні роботи',
      topics: 432,
      posts: 2890,
      lastTopic: 'Укладання плитки у ванній',
      lastAuthor: 'Марія С.',
      lastTime: '3 дні тому',
    },
    {
      title: 'Покрівельні роботи',
      topics: 321,
      posts: 2134,
      lastTopic: 'М\'яка покрівля vs металочерепиця',
      lastAuthor: 'Петро К.',
      lastTime: 'тиждень тому',
    },
  ];

  const popularTopics = [
    { title: 'Повний гід з ремонту квартири 2024', replies: 156, views: 12453 },
    { title: 'Як уникнути шахрайства при ремонті', replies: 89, views: 8932 },
    { title: 'Калькулятор вартості ремонту - огляд', replies: 67, views: 7654 },
    { title: 'Поради з вибору будівельної бригади', replies: 45, views: 5432 },
  ];

  return (
    <div className="min-h-screen bg-light">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Форум будівельників</h1>
          <p className="text-gray-600 mt-2">Обговорення ремонту, будівництва та все що з ним пов'язано</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex gap-8">
          {/* Main content */}
          <div className="flex-1">
            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="bg-white rounded-lg shadow-sm p-4 text-center">
                <div className="text-2xl font-bold text-[#5b9bd5]">4 211</div>
                <div className="text-sm text-gray-600">Тем</div>
              </div>
              <div className="bg-white rounded-lg shadow-sm p-4 text-center">
                <div className="text-2xl font-bold text-[#5b9bd5]">27 317</div>
                <div className="text-sm text-gray-600">Повідомлень</div>
              </div>
              <div className="bg-white rounded-lg shadow-sm p-4 text-center">
                <div className="text-2xl font-bold text-[#5b9bd5]">8 432</div>
                <div className="text-sm text-gray-600">Користувачів</div>
              </div>
            </div>

            {/* Forum sections */}
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="bg-[#2e5c8a] text-white px-6 py-3">
                <h2 className="font-bold">Розділи форуму</h2>
              </div>
              
              <div className="divide-y">
                {forumSections.map((section, idx) => (
                  <div key={idx} className="p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 bg-[#5b9bd5]/10 rounded flex items-center justify-center flex-shrink-0">
                          <MessageSquare className="text-[#5b9bd5]" size={20} />
                        </div>
                        <div>
                          <h3 className="font-medium text-[#5b9bd5] hover:underline cursor-pointer">
                            {section.title}
                          </h3>
                          <div className="flex items-center gap-4 text-sm text-gray-500 mt-1">
                            <span className="flex items-center gap-1">
                              <MessageCircle size={14} />
                              {section.topics} тем
                            </span>
                            <span className="flex items-center gap-1">
                              <Users size={14} />
                              {section.posts} повідомлень
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right text-sm">
                        <p className="text-[#5b9bd5] hover:underline cursor-pointer truncate max-w-[200px]">
                          {section.lastTopic}
                        </p>
                        <p className="text-gray-500 mt-1">
                          {section.lastAuthor} • {section.lastTime}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="w-80 flex-shrink-0">
            {/* Popular topics */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp size={20} className="text-[#5b9bd5]" />
                <h3 className="font-bold">Популярні теми</h3>
              </div>
              <div className="space-y-3">
                {popularTopics.map((topic, idx) => (
                  <div key={idx} className="border-b last:border-0 pb-3 last:pb-0">
                    <p className="text-sm text-[#5b9bd5] hover:underline cursor-pointer">
                      {topic.title}
                    </p>
                    <div className="flex items-center gap-3 text-xs text-gray-500 mt-1">
                      <span>{topic.replies} відповідей</span>
                      <span>{topic.views} переглядів</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Online users */}
            <div className="bg-white rounded-lg shadow-sm p-4">
              <div className="flex items-center gap-2 mb-4">
                <Users size={20} className="text-[#5b9bd5]" />
                <h3 className="font-bold">Зараз на форумі</h3>
              </div>
              <p className="text-gray-600 text-sm">
                <strong>127</strong> користувачів онлайн
              </p>
              <p className="text-gray-500 text-xs mt-1">
                З них: <strong>45</strong> зареєстрованих, <strong>82</strong> гостей
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
