import { useState } from 'react';
import { serviceCategories } from '@/data/servicesData';
import { ArrowLeft, ArrowRight, Check, MapPin, Calendar, Clock, Phone, Mail, User } from 'lucide-react';

interface CreateOrderPageProps {
  onPageChange: (page: string, params?: any) => void;
  preselectedService?: string;
}

export function CreateOrderPage({ onPageChange, preselectedService }: CreateOrderPageProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    category: '',
    subcategory: '',
    service: preselectedService || '',
    title: '',
    description: '',
    address: '',
    date: '',
    time: '',
    budget: '',
    name: '',
    phone: '',
    email: '',
    agreeTerms: false,
  });

  const updateForm = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const selectedCategory = serviceCategories.find(c => c.id === formData.category);
  const selectedSubcategory = selectedCategory?.subcategories?.find(s => s.id === formData.subcategory);

  const handleNext = () => {
    if (step < 4) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = () => {
    alert('Завдання успішно створено! Очікуйте пропозицій від виконавців.');
    onPageChange('my-orders');
  };

  const isStepValid = () => {
    switch (step) {
      case 1: return formData.category && formData.subcategory && formData.service;
      case 2: return formData.title && formData.description && formData.address;
      case 3: return formData.date && formData.time && formData.budget;
      case 4: return formData.name && formData.phone && formData.agreeTerms;
      default: return false;
    }
  };

  return (
    <div className="max-w-2xl mx-auto pb-8">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <button onClick={() => onPageChange('home')} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
          <ArrowLeft size={20} />
        </button>
        <div>
          <h1 className="text-xl font-bold text-gray-800">Створити завдання</h1>
          <p className="text-gray-500 text-sm">Опишіть ваше завдання та отримайте пропозиції</p>
        </div>
      </div>

      {/* Progress */}
      <div className="bg-white rounded-xl p-4 mb-6 card-shadow">
        <div className="flex items-center justify-between">
          {[
            { num: 1, label: 'Послуга' },
            { num: 2, label: 'Опис' },
            { num: 3, label: 'Дата' },
            { num: 4, label: 'Контакти' },
          ].map((s, idx) => (
            <div key={idx} className="flex items-center">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${
                step > s.num ? 'bg-[#10B981] text-white' :
                step === s.num ? 'bg-[#8B5CF6] text-white' : 
                'bg-gray-100 text-gray-400'
              }`}>
                {step > s.num ? <Check size={14} /> : s.num}
              </div>
              <span className={`hidden sm:inline ml-2 text-xs ${step >= s.num ? 'text-gray-700' : 'text-gray-400'}`}>
                {s.label}
              </span>
              {idx < 3 && <div className="w-4 sm:w-8 h-0.5 mx-2 bg-gray-100" />}
            </div>
          ))}
        </div>
      </div>

      {/* Form */}
      <div className="bg-white rounded-xl card-shadow p-6">
        {/* Step 1: Service selection */}
        {step === 1 && (
          <div className="space-y-5">
            <h2 className="text-lg font-semibold text-gray-800">Оберіть послугу</h2>
            
            {/* Category */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Категорія</label>
              <div className="grid grid-cols-2 gap-3">
                {serviceCategories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      updateForm('category', cat.id);
                      updateForm('subcategory', '');
                      updateForm('service', '');
                    }}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      formData.category === cat.id
                        ? 'border-[#8B5CF6] bg-[#8B5CF6]/5 ring-2 ring-[#8B5CF6]/20'
                        : 'border-gray-200 hover:border-[#8B5CF6]/50'
                    }`}
                  >
                    <div className="text-2xl mb-1">{cat.icon}</div>
                    <div className="text-sm font-medium text-gray-800">{cat.name}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Subcategory */}
            {selectedCategory && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Підкатегорія</label>
                <div className="grid gap-2">
                  {selectedCategory.subcategories?.map((sub) => (
                    <button
                      key={sub.id}
                      onClick={() => {
                        updateForm('subcategory', sub.id);
                        updateForm('service', '');
                      }}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        formData.subcategory === sub.id
                          ? 'border-[#8B5CF6] bg-[#8B5CF6]/5 ring-2 ring-[#8B5CF6]/20'
                          : 'border-gray-200 hover:border-[#8B5CF6]/50'
                      }`}
                    >
                      <div className="font-medium text-gray-800">{sub.name}</div>
                      <div className="text-xs text-gray-500">{sub.description}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Service */}
            {selectedSubcategory && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Послуга</label>
                <div className="space-y-2">
                  {selectedSubcategory.services?.map((service) => (
                    <button
                      key={service.id}
                      onClick={() => updateForm('service', service.id)}
                      className={`w-full p-4 rounded-xl border text-left transition-all flex items-center justify-between ${
                        formData.service === service.id
                          ? 'border-[#8B5CF6] bg-[#8B5CF6]/5 ring-2 ring-[#8B5CF6]/20'
                          : 'border-gray-200 hover:border-[#8B5CF6]/50'
                      }`}
                    >
                      <div>
                        <div className="font-medium text-gray-800 flex items-center gap-2">
                          {service.name}
                          {service.popular && (
                            <span className="bg-[#8B5CF6]/10 text-[#8B5CF6] text-xs px-2 py-0.5 rounded-full">
                              Популярне
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-gray-500">{service.description}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-[#8B5CF6]">
                          {service.priceFrom && 'від '}{service.basePrice} грн
                        </div>
                        <div className="text-xs text-gray-400">{service.unit}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Step 2: Description */}
        {step === 2 && (
          <div className="space-y-5">
            <h2 className="text-lg font-semibold text-gray-800">Опишіть завдання</h2>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Заголовок *</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => updateForm('title', e.target.value)}
                placeholder="Наприклад: Косметичний ремонт кухні 12 м²"
                className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:border-[#8B5CF6] transition-colors"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Детальний опис *</label>
              <textarea
                value={formData.description}
                onChange={(e) => updateForm('description', e.target.value)}
                placeholder="Опишіть детально, що потрібно зробити..."
                rows={4}
                className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:border-[#8B5CF6] transition-colors resize-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Адреса *</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => updateForm('address', e.target.value)}
                  placeholder="м. Київ, вул. Хрещатик, 1, кв. 10"
                  className="w-full border border-gray-200 rounded-xl pl-10 pr-4 py-3 focus:border-[#8B5CF6] transition-colors"
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 3: Date & Budget */}
        {step === 3 && (
          <div className="space-y-5">
            <h2 className="text-lg font-semibold text-gray-800">Коли та за скільки?</h2>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Дата *</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => updateForm('date', e.target.value)}
                    className="w-full border border-gray-200 rounded-xl pl-10 pr-4 py-3 focus:border-[#8B5CF6] transition-colors"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Час *</label>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                  <input
                    type="time"
                    value={formData.time}
                    onChange={(e) => updateForm('time', e.target.value)}
                    className="w-full border border-gray-200 rounded-xl pl-10 pr-4 py-3 focus:border-[#8B5CF6] transition-colors"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Бюджет (грн) *</label>
              <input
                type="number"
                value={formData.budget}
                onChange={(e) => updateForm('budget', e.target.value)}
                placeholder="Наприклад: 5000"
                className="w-full border border-gray-200 rounded-xl px-4 py-3 focus:border-[#8B5CF6] transition-colors"
              />
              <p className="text-xs text-gray-500 mt-1">Вкажіть орієнтовний бюджет</p>
            </div>
          </div>
        )}

        {/* Step 4: Contacts */}
        {step === 4 && (
          <div className="space-y-5">
            <h2 className="text-lg font-semibold text-gray-800">Ваші контакти</h2>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Ім'я *</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => updateForm('name', e.target.value)}
                  placeholder="Ваше ім'я"
                  className="w-full border border-gray-200 rounded-xl pl-10 pr-4 py-3 focus:border-[#8B5CF6] transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Телефон *</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => updateForm('phone', e.target.value)}
                  placeholder="+38 (0XX) XXX-XX-XX"
                  className="w-full border border-gray-200 rounded-xl pl-10 pr-4 py-3 focus:border-[#8B5CF6] transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => updateForm('email', e.target.value)}
                  placeholder="your@email.com"
                  className="w-full border border-gray-200 rounded-xl pl-10 pr-4 py-3 focus:border-[#8B5CF6] transition-colors"
                />
              </div>
            </div>

            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                id="agree"
                checked={formData.agreeTerms}
                onChange={(e) => updateForm('agreeTerms', e.target.checked)}
                className="mt-1 accent-[#8B5CF6]"
              />
              <label htmlFor="agree" className="text-sm text-gray-600">
                Я погоджуюсь з <button className="text-[#8B5CF6] hover:underline">умовами використання</button>
              </label>
            </div>
          </div>
        )}

        {/* Buttons */}
        <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-100">
          <button
            onClick={handleBack}
            disabled={step === 1}
            className="px-5 py-2.5 border border-gray-200 rounded-xl text-gray-600 hover:border-[#8B5CF6] hover:text-[#8B5CF6] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Назад
          </button>
          {step < 4 ? (
            <button
              onClick={handleNext}
              disabled={!isStepValid()}
              className="px-5 py-2.5 bg-[#8B5CF6] text-white rounded-xl hover:bg-[#7C3AED] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              <span>Далі</span>
              <ArrowRight size={16} />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={!isStepValid()}
              className="px-5 py-2.5 bg-[#8B5CF6] text-white rounded-xl hover:bg-[#7C3AED] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              <Check size={16} />
              <span>Створити завдання</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
