import { useState } from 'react';
import { UserPlus, Mail, Lock, Eye, EyeOff, User, Phone, Building2 } from 'lucide-react';

interface SignupPageProps {
  onPageChange: (page: string, params?: any) => void;
}

export function SignupPage({ onPageChange }: SignupPageProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    userType: 'customer', // 'customer' or 'worker'
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      alert('Паролі не співпадають!');
      return;
    }
    if (!agreeTerms) {
      alert('Погодьтеся з умовами використання!');
      return;
    }
    alert('Реєстрація успішна!');
    onPageChange('home');
  };

  return (
    <div className="min-h-screen bg-light py-12">
      <div className="max-w-md mx-auto px-4">
        <div className="bg-white rounded-lg shadow-sm p-8">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-[#5b9bd5] rounded-full flex items-center justify-center mx-auto mb-4">
              <UserPlus className="text-white" size={32} />
            </div>
            <h1 className="text-2xl font-bold">Реєстрація</h1>
            <p className="text-gray-500 mt-2">Створіть новий обліковий запис</p>
          </div>

          {/* User type selection */}
          <div className="flex gap-3 mb-6">
            <button
              type="button"
              onClick={() => setFormData(prev => ({ ...prev, userType: 'customer' }))}
              className={`flex-1 py-3 px-4 rounded-lg border-2 transition-colors ${
                formData.userType === 'customer'
                  ? 'border-[#5b9bd5] bg-[#5b9bd5]/10 text-[#5b9bd5]'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex flex-col items-center">
                <User size={24} className="mb-1" />
                <span className="text-sm font-medium">Я замовник</span>
              </div>
            </button>
            <button
              type="button"
              onClick={() => setFormData(prev => ({ ...prev, userType: 'worker' }))}
              className={`flex-1 py-3 px-4 rounded-lg border-2 transition-colors ${
                formData.userType === 'worker'
                  ? 'border-[#5b9bd5] bg-[#5b9bd5]/10 text-[#5b9bd5]'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex flex-col items-center">
                <Building2 size={24} className="mb-1" />
                <span className="text-sm font-medium">Я майстер</span>
              </div>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Ім'я та прізвище
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-lg pl-10 pr-4 py-3 focus:outline-none focus:border-[#5b9bd5] focus:ring-1 focus:ring-[#5b9bd5]"
                  placeholder="Введіть ім'я та прізвище"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-lg pl-10 pr-4 py-3 focus:outline-none focus:border-[#5b9bd5] focus:ring-1 focus:ring-[#5b9bd5]"
                  placeholder="Введіть email"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Телефон
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-lg pl-10 pr-4 py-3 focus:outline-none focus:border-[#5b9bd5] focus:ring-1 focus:ring-[#5b9bd5]"
                  placeholder="+38 (0XX) XXX-XX-XX"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Пароль
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-lg pl-10 pr-12 py-3 focus:outline-none focus:border-[#5b9bd5] focus:ring-1 focus:ring-[#5b9bd5]"
                  placeholder="Введіть пароль"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Підтвердження паролю
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-lg pl-10 pr-12 py-3 focus:outline-none focus:border-[#5b9bd5] focus:ring-1 focus:ring-[#5b9bd5]"
                  placeholder="Повторіть пароль"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showConfirmPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div>
              <label className="flex items-start gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={agreeTerms}
                  onChange={(e) => setAgreeTerms(e.target.checked)}
                  className="mt-1 text-[#5b9bd5]"
                />
                <span className="text-sm text-gray-600">
                  Я погоджуюсь з{' '}
                  <button type="button" className="text-[#5b9bd5] hover:underline">
                    умовами використання
                  </button>{' '}
                  та{' '}
                  <button type="button" className="text-[#5b9bd5] hover:underline">
                    політикою конфіденційності
                  </button>
                </span>
              </label>
            </div>

            <button
              type="submit"
              className="w-full bg-[#5b9bd5] text-white py-3 rounded-lg font-medium hover:bg-[#4a8ac4] transition-colors"
            >
              Зареєструватися
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600">
              Вже маєте обліковий запис?{' '}
              <button
                onClick={() => onPageChange('login')}
                className="text-[#5b9bd5] hover:underline font-medium"
              >
                Увійти
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
