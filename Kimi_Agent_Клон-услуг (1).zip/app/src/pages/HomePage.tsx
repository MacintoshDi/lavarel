import { serviceCategories } from '@/data/servicesData';
import { ArrowRight, Star, CheckCircle, Clock, Shield } from 'lucide-react';

interface HomePageProps {
  onPageChange: (page: string, params?: any) => void;
}

export function HomePage({ onPageChange }: HomePageProps) {
  return (
    <div className="space-y-8 pb-8">
      {/* Welcome Card */}
      <div className="bg-white rounded-2xl card-shadow overflow-hidden">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="p-6 lg:p-8">
            <div className="inline-flex items-center gap-2 bg-[#8B5CF6]/10 text-[#8B5CF6] px-3 py-1 rounded-full text-sm font-medium mb-4">
              <span>👋</span>
              <span>Ласкаво просимо!</span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-bold text-gray-800 mb-3">
              Знайдіть надійного майстра для будь-якої роботи
            </h1>
            <p className="text-gray-500 mb-6">
              Понад 50 000 перевірених виконавців готові допомогти вам. 
              Створіть завдання та отримайте пропозиції за 5 хвилин.
            </p>
            <div className="flex flex-wrap gap-3">
              <button 
                onClick={() => onPageChange('create-order')}
                className="btn-primary flex items-center gap-2"
              >
                <span>Створити завдання</span>
                <ArrowRight size={16} />
              </button>
              <button 
                onClick={() => onPageChange('categories')}
                className="px-4 py-2 border border-gray-200 rounded-lg text-gray-600 hover:border-[#8B5CF6] hover:text-[#8B5CF6] transition-colors"
              >
                Переглянути послуги
              </button>
            </div>
          </div>
          <div className="hidden md:flex items-center justify-center bg-gradient-to-br from-[#8B5CF6]/10 to-[#A78BFA]/10 p-8">
            <div className="relative">
              <div className="w-48 h-48 bg-white rounded-2xl shadow-xl flex items-center justify-center">
                <span className="text-6xl">🛠️</span>
              </div>
              <div className="absolute -top-4 -right-4 w-16 h-16 bg-[#8B5CF6] rounded-xl flex items-center justify-center shadow-lg">
                <CheckCircle className="text-white" size={28} />
              </div>
              <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-[#10B981] rounded-xl flex items-center justify-center shadow-lg">
                <Star className="text-white" size={28} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* What can you find here */}
      <div className="bg-white rounded-2xl card-shadow p-6 lg:p-8">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="order-2 md:order-1">
            <div className="grid grid-cols-3 gap-4">
              {[
                { icon: '🔨', label: 'Ремонт' },
                { icon: '🚿', label: 'Сантехніка' },
                { icon: '⚡', label: 'Електрика' },
                { icon: '🧹', label: 'Прибирання' },
                { icon: '📦', label: 'Вантажники' },
                { icon: '🪑', label: 'Меблі' },
              ].map((item, idx) => (
                <div 
                  key={idx} 
                  className="aspect-square bg-[#F5F3FF] rounded-xl flex flex-col items-center justify-center gap-2 hover:bg-[#EDE9FE] transition-colors cursor-pointer"
                  onClick={() => onPageChange('categories')}
                >
                  <span className="text-2xl">{item.icon}</span>
                  <span className="text-xs text-gray-600">{item.label}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="order-1 md:order-2">
            <h2 className="text-xl font-bold text-gray-800 mb-3">Що ви можете тут знайти?</h2>
            <p className="text-gray-500">
              У нас ви знайдете все — від обговорень до ресурсів та навіть 
              приклади робіт, щоб мати все в одному місці.
            </p>
          </div>
        </div>
      </div>

      {/* Categories Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-gray-800">Категорії послуг</h2>
          <button 
            onClick={() => onPageChange('categories')}
            className="text-[#8B5CF6] text-sm font-medium hover:underline flex items-center gap-1"
          >
            Всі категорії <ArrowRight size={14} />
          </button>
        </div>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {serviceCategories.map((category) => (
            <button
              key={category.id}
              onClick={() => onPageChange('categories', { category: category.id })}
              className="bg-white rounded-xl p-5 card-shadow card-hover text-left group"
            >
              <div className="text-3xl mb-3 group-hover:scale-110 transition-transform">{category.icon}</div>
              <h3 className="font-semibold text-gray-800 mb-1 group-hover:text-[#8B5CF6] transition-colors">
                {category.name}
              </h3>
              <p className="text-xs text-gray-500 line-clamp-2">{category.description}</p>
            </button>
          ))}
        </div>
      </div>

      {/* How to get started */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-gray-800">Як почати?</h2>
            <p className="text-sm text-gray-500">Оберіть категорію нижче, щоб перейти до послуг</p>
          </div>
          <button 
            onClick={() => onPageChange('how-it-works')}
            className="text-[#8B5CF6] text-sm font-medium hover:underline"
          >
            Детальніше
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          {[
            { 
              step: '1', 
              title: 'Опишіть завдання', 
              desc: 'Розкажіть, яку послугу вам потрібно',
              color: 'bg-[#8B5CF6]'
            },
            { 
              step: '2', 
              title: 'Отримайте пропозиції', 
              desc: 'Виконавці самі зв\'яжуться з вами',
              color: 'bg-[#A78BFA]'
            },
            { 
              step: '3', 
              title: 'Оберіть виконавця', 
              desc: 'Порівняйте ціни та відгуки',
              color: 'bg-[#C4B5FD]'
            },
          ].map((item, idx) => (
            <div key={idx} className="bg-white rounded-xl p-5 card-shadow">
              <div className={`w-10 h-10 ${item.color} rounded-lg flex items-center justify-center text-white font-bold mb-3`}>
                {item.step}
              </div>
              <h3 className="font-semibold text-gray-800 mb-1">{item.title}</h3>
              <p className="text-sm text-gray-500">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] rounded-2xl p-6 lg:p-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center text-white">
          <div>
            <div className="text-3xl lg:text-4xl font-bold mb-1">50K+</div>
            <div className="text-white/70 text-sm">Виконавців</div>
          </div>
          <div>
            <div className="text-3xl lg:text-4xl font-bold mb-1">200K+</div>
            <div className="text-white/70 text-sm">Завдань</div>
          </div>
          <div>
            <div className="text-3xl lg:text-4xl font-bold mb-1">1K+</div>
            <div className="text-white/70 text-sm">Послуг</div>
          </div>
          <div>
            <div className="text-3xl lg:text-4xl font-bold mb-1">4.8</div>
            <div className="text-white/70 text-sm">Рейтинг</div>
          </div>
        </div>
      </div>

      {/* Why us */}
      <div className="bg-white rounded-2xl card-shadow p-6 lg:p-8">
        <h2 className="text-xl font-bold text-gray-800 mb-6 text-center">Чому обирають нас</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: CheckCircle, title: 'Перевірені виконавці', desc: 'Всі виконавці проходять верифікацію' },
            { icon: Clock, title: 'Економія часу', desc: 'Отримайте пропозиції за 5 хвилин' },
            { icon: Shield, title: 'Гарантія якості', desc: 'Оплата після виконання роботи' },
          ].map((benefit, idx) => {
            const Icon = benefit.icon;
            return (
              <div key={idx} className="text-center">
                <div className="w-12 h-12 bg-[#F5F3FF] rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Icon className="text-[#8B5CF6]" size={24} />
                </div>
                <h3 className="font-semibold text-gray-800 mb-1">{benefit.title}</h3>
                <p className="text-sm text-gray-500">{benefit.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
