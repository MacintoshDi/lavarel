import { useState } from 'react';
import { tenders } from '@/data/mockData';
import { Search, Plus, Eye, MessageCircle, X, Clock, Briefcase } from 'lucide-react';

interface TendersPageProps {
  onPageChange: (page: string, params?: any) => void;
}

export function TendersPage({ onPageChange }: TendersPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAllTenders, setShowAllTenders] = useState(true);
  const [selectedRegion, setSelectedRegion] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedBudget, setSelectedBudget] = useState<string[]>([]);
  const [showBanner, setShowBanner] = useState(true);

  const budgetRanges = [
    { id: 'to-7000', label: 'до 7 000 грн' },
    { id: '7000-30000', label: 'від 7 000 до 30 000 грн' },
    { id: '30000-100000', label: 'від 30 000 до 100 000 грн' },
    { id: '100000-500000', label: 'від 100 000 до 500 000 грн' },
    { id: 'over-500000', label: 'понад 500 000 грн' },
  ];

  const handleBudgetChange = (id: string) => {
    setSelectedBudget(prev => 
      prev.includes(id) 
        ? prev.filter(b => b !== id)
        : [...prev, id]
    );
  };

  return (
    <div className="min-h-screen bg-light">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Будівельні тендери та замовлення на ремонт</h1>
          <p className="text-gray-600 mt-2">Всього знайдено <strong>175063</strong> тендерів.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex gap-8">
          {/* Main content */}
          <div className="flex-1">
            {/* Create tender button */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <button 
                onClick={() => onPageChange('create-tender')}
                className="btn-orange text-white px-6 py-3 rounded flex items-center gap-2 hover:bg-[#e06015] transition-colors"
              >
                <Plus size={20} />
                <span>Створити тендер</span>
              </button>
            </div>

            {/* Promo banner */}
            {showBanner && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4 relative">
                <button 
                  onClick={() => setShowBanner(false)}
                  className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
                >
                  <X size={18} />
                </button>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-amber-100 rounded flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">📦</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-[#5b9bd5]">Продаж залишків після ремонту</h4>
                    <p className="text-sm text-gray-600 mt-1">
                      Ми запустили новий розділ сайту Materialy.com.ua для продажу залишків матеріалів після ремонту.
                      Сподіваємося Вам сподобається :-)
                    </p>
                    <a href="#" className="text-sm text-[#5b9bd5] hover:underline mt-2 inline-block">
                      https://www.materialy.ua
                    </a>
                  </div>
                </div>
              </div>
            )}

            {/* Tenders list */}
            <div className="space-y-4">
              {tenders.map((tender) => (
                <div 
                  key={tender.id} 
                  className="tender-card p-6 cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => onPageChange('tender-detail', { id: tender.id })}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <span className="tender-number">№{tender.id}</span>
                      <h3 className="text-lg font-medium text-[#5b9bd5] hover:underline">{tender.title}</h3>
                      {tender.isTop && (
                        <span className="top-badge flex items-center gap-1">
                          <span>★</span> ТОП
                        </span>
                      )}
                      {tender.isTranslated && (
                        <span className="text-xs text-gray-500 flex items-center gap-1">
                          <span>🌐</span> Авто-переклад
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-16 bg-[#5b9bd5] rounded flex items-center justify-center flex-shrink-0">
                      <Briefcase className="text-white" size={28} />
                    </div>
                    <div className="flex-1">
                      <p className="text-gray-600 text-sm mb-3 whitespace-pre-line">{tender.description}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <Eye size={14} />
                            {tender.views}
                          </span>
                          <span className="flex items-center gap-1">
                            <MessageCircle size={14} />
                            {tender.responses} відповідей
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock size={14} />
                            {tender.date}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-gray-600 font-medium">Бюджет {tender.budget}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Leaders section */}
            <div className="mt-8">
              <h2 className="text-xl font-bold mb-4">Лідери каталогу</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white rounded-lg shadow-sm p-4">
                  <h4 className="font-bold text-[#5b9bd5]">Бригада "Плиточні роботи"</h4>
                  <p className="text-sm text-gray-500">Сарни</p>
                  <p className="text-sm text-gray-600 mt-2 line-clamp-3">
                    Вітаю!!! Команда плиточників, з усім необхідним інструментом та навичками...
                  </p>
                </div>
                <div className="bg-white rounded-lg shadow-sm p-4">
                  <h4 className="font-bold text-[#5b9bd5]">Компанія "Пан-Буд"</h4>
                  <p className="text-sm text-gray-500">Київ</p>
                  <p className="text-sm text-gray-600 mt-2 line-clamp-3">
                    ПАН-БУД Ваш надійний партнер у будівництві і ремонті...
                  </p>
                </div>
                <div className="bg-white rounded-lg shadow-sm p-4">
                  <h4 className="font-bold text-[#5b9bd5]">ФОП СОЛОЩУК РОМАН</h4>
                  <p className="text-sm text-gray-500">Київ</p>
                  <p className="text-sm text-gray-600 mt-2 line-clamp-3">
                    Якісний ремонт квартир та будинків під ключ...
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="w-80 flex-shrink-0">
            {/* Search */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <h3 className="font-bold mb-4">Пошук по всіх тендерах</h3>
              <div className="flex">
                <input
                  type="text"
                  placeholder="№ тендеру або назва"
                  className="flex-1 border border-gray-300 rounded-l px-3 py-2 text-sm focus:outline-none focus:border-[#5b9bd5]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <button className="bg-[#5b9bd5] text-white px-4 py-2 rounded-r hover:bg-[#4a8ac4] transition-colors">
                  <Search size={16} />
                </button>
              </div>
            </div>

            {/* Filters */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <h3 className="font-bold mb-4">Показати тендери</h3>
              <div className="space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="radio" 
                    name="tender-type" 
                    checked={showAllTenders}
                    onChange={() => setShowAllTenders(true)}
                    className="text-[#5b9bd5]"
                  />
                  <span className="text-sm">Всі тендери</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="radio" 
                    name="tender-type" 
                    checked={!showAllTenders}
                    onChange={() => setShowAllTenders(false)}
                    className="text-[#5b9bd5]"
                  />
                  <span className="text-sm">Відкриті тендери</span>
                </label>
              </div>
            </div>

            {/* Region filter */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <h3 className="font-bold mb-4">Регіон</h3>
              <div className="space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="radio" 
                    name="region" 
                    checked={selectedRegion === 'all'}
                    onChange={() => setSelectedRegion('all')}
                    className="text-[#5b9bd5]"
                  />
                  <span className="text-sm">Вся Україна</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="radio" 
                    name="region" 
                    checked={selectedRegion === 'select'}
                    onChange={() => setSelectedRegion('select')}
                    className="text-[#5b9bd5]"
                  />
                  <span className="text-sm">Вибір зі списку</span>
                </label>
              </div>
            </div>

            {/* Category filter */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <h3 className="font-bold mb-4">Види робіт</h3>
              <div className="space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="radio" 
                    name="category" 
                    checked={selectedCategory === 'all'}
                    onChange={() => setSelectedCategory('all')}
                    className="text-[#5b9bd5]"
                  />
                  <span className="text-sm">Всі види робіт</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="radio" 
                    name="category" 
                    checked={selectedCategory === 'select'}
                    onChange={() => setSelectedCategory('select')}
                    className="text-[#5b9bd5]"
                  />
                  <span className="text-sm">Вибір зі списку</span>
                </label>
              </div>
            </div>

            {/* Budget filter */}
            <div className="bg-white rounded-lg shadow-sm p-4">
              <h3 className="font-bold mb-4">Бюджет</h3>
              <div className="space-y-2">
                {budgetRanges.map((range) => (
                  <label key={range.id} className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={selectedBudget.includes(range.id)}
                      onChange={() => handleBudgetChange(range.id)}
                      className="text-[#5b9bd5]"
                    />
                    <span className="text-sm">{range.label}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
