import { useState } from 'react';
import { vacancies, specialties, regions } from '@/data/mockData';
import { Search, Plus, MapPin, Briefcase, Clock, Eye, Building2 } from 'lucide-react';

interface JobsPageProps {
  onPageChange: (page: string, params?: any) => void;
}

export function JobsPage({ onPageChange }: JobsPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('');
  const [employmentType, setEmploymentType] = useState('all');

  const employmentTypes = [
    { id: 'all', label: 'Всі' },
    { id: 'permanent', label: 'Постійна робота' },
    { id: 'project', label: 'Робота на один об\'єкт' },
    { id: 'seasonal', label: 'Робота на сезон' },
    { id: 'parttime', label: 'Підробіток' },
    { id: 'remote', label: 'Дистанційна робота' },
  ];

  return (
    <div className="min-h-screen bg-light">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Робота для будівельників</h1>
          <p className="text-gray-600 mt-2">Всього знайдено <strong>4457</strong> вакансій.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex gap-8">
          {/* Main content */}
          <div className="flex-1">
            {/* Create vacancy button */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <button 
                onClick={() => onPageChange('create-vacancy')}
                className="btn-orange text-white px-6 py-3 rounded flex items-center gap-2 hover:bg-[#e06015] transition-colors"
              >
                <Plus size={20} />
                <span>Створити вакансію</span>
              </button>
            </div>

            {/* Vacancies list */}
            <div className="space-y-4">
              {vacancies.map((vacancy) => (
                <div 
                  key={vacancy.id} 
                  className="bg-white rounded-lg shadow-sm p-6 cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => onPageChange('vacancy-detail', { id: vacancy.id })}
                >
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-16 bg-gray-800 rounded flex items-center justify-center flex-shrink-0">
                      <Building2 className="text-gray-400" size={32} />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-medium text-[#5b9bd5] hover:underline">{vacancy.title}</h3>
                      
                      <div className="flex items-center gap-4 mt-2">
                        <span className="font-medium text-gray-800">{vacancy.company}</span>
                      </div>

                      <div className="grid grid-cols-2 gap-2 mt-3">
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <MapPin size={14} />
                          <span>{vacancy.location}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Briefcase size={14} />
                          <span>{vacancy.salary}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Building2 size={14} />
                          <span>{vacancy.specialty}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Clock size={14} />
                          <span>{vacancy.type}</span>
                        </div>
                      </div>

                      <p className="text-gray-600 text-sm mt-3 line-clamp-2">{vacancy.description}</p>

                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <Eye size={14} />
                            {vacancy.views}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock size={14} />
                            {vacancy.date}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="w-80 flex-shrink-0">
            {/* Search */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <h3 className="font-bold mb-4">Пошук по всіх вакансіях</h3>
              <div className="flex">
                <input
                  type="text"
                  placeholder="№ вакансії або назва"
                  className="flex-1 border border-gray-300 rounded-l px-3 py-2 text-sm focus:outline-none focus:border-[#5b9bd5]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <button className="bg-[#5b9bd5] text-white px-4 py-2 rounded-r hover:bg-[#4a8ac4] transition-colors">
                  <Search size={16} />
                </button>
              </div>
            </div>

            {/* Specialty filter */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <h3 className="font-bold mb-4">Спеціальність</h3>
              <select 
                className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-[#5b9bd5]"
                value={selectedSpecialty}
                onChange={(e) => setSelectedSpecialty(e.target.value)}
              >
                <option value="">- Неважливо -</option>
                {specialties.map((spec, idx) => (
                  <option key={idx} value={spec}>{spec}</option>
                ))}
              </select>
            </div>

            {/* Region filter */}
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <h3 className="font-bold mb-4">Місце роботи</h3>
              <select 
                className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:border-[#5b9bd5]"
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
              >
                <option value="">- Неважливо -</option>
                {regions.map((region, idx) => (
                  <option key={idx} value={region}>{region}</option>
                ))}
              </select>
            </div>

            {/* Employment type filter */}
            <div className="bg-white rounded-lg shadow-sm p-4">
              <h3 className="font-bold mb-4">Вид зайнятості</h3>
              <div className="space-y-2">
                {employmentTypes.map((type) => (
                  <label key={type.id} className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="radio" 
                      name="employment"
                      checked={employmentType === type.id}
                      onChange={() => setEmploymentType(type.id)}
                      className="text-[#5b9bd5]"
                    />
                    <span className="text-sm">{type.label}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
