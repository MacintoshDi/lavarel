import { useState } from 'react';
import { serviceCategories, priceTables } from '@/data/servicesData';
import { ArrowRight, Check, Phone, MessageSquare, ChevronLeft } from 'lucide-react';

interface PriceTablePageProps {
  onPageChange: (page: string, params?: any) => void;
  categoryId?: string;
  subcategoryId?: string;
}

export function PriceTablePage({ onPageChange, categoryId, subcategoryId }: PriceTablePageProps) {
  const [selectedTable, setSelectedTable] = useState(0);

  const category = serviceCategories.find(c => c.id === categoryId);
  const subcategory = category?.subcategories?.find(s => s.id === subcategoryId);
  const tables = subcategoryId ? priceTables[subcategoryId] || [] : [];

  if (!category || !subcategory) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <h1 className="text-xl font-bold text-gray-800 mb-2">Категорію не знайдено</h1>
          <button 
            onClick={() => onPageChange('categories')}
            className="text-[#8B5CF6] hover:underline"
          >
            Повернутися до категорій
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-gray-500">
        <button onClick={() => onPageChange('categories')} className="hover:text-[#8B5CF6]">Всі послуги</button>
        <ArrowRight size={14} />
        <button onClick={() => onPageChange('categories', { category: categoryId })} className="hover:text-[#8B5CF6]">
          {category.name}
        </button>
        <ArrowRight size={14} />
        <span className="text-gray-800">{subcategory.name}</span>
      </div>

      {/* Header */}
      <div className="flex items-center gap-4">
        <button 
          onClick={() => onPageChange('categories', { category: categoryId })}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ChevronLeft size={20} />
        </button>
        <div className="text-3xl">{subcategory.icon}</div>
        <div>
          <h1 className="text-xl font-bold text-gray-800">{subcategory.name}</h1>
          <p className="text-gray-500 text-sm">{subcategory.description}</p>
        </div>
      </div>

      {/* Services list */}
      <div className="bg-white rounded-xl card-shadow overflow-hidden">
        <div className="p-5 border-b border-gray-100 bg-gray-50">
          <h2 className="font-semibold text-gray-800">Послуги та ціни</h2>
        </div>
        <div className="divide-y divide-gray-100">
          {subcategory.services?.map((service) => (
            <div key={service.id} className="p-5 flex items-center justify-between hover:bg-gray-50 transition-colors">
              <div className="flex-1">
                <div className="font-medium text-gray-800 flex items-center gap-2">
                  {service.name}
                  {service.popular && (
                    <span className="bg-[#8B5CF6]/10 text-[#8B5CF6] text-xs px-2 py-0.5 rounded-full">
                      Популярне
                    </span>
                  )}
                </div>
                <div className="text-sm text-gray-500">{service.description}</div>
              </div>
              <div className="text-right flex-shrink-0 ml-4">
                <div className="text-xl font-semibold text-[#8B5CF6]">
                  {service.priceFrom && 'від '}{service.basePrice} <span className="text-sm">грн</span>
                </div>
                <div className="text-xs text-gray-400">{service.unit}</div>
              </div>
              <button 
                onClick={() => onPageChange('create-order', { service: service.id })}
                className="ml-4 bg-[#8B5CF6] text-white px-4 py-2 rounded-lg hover:bg-[#7C3AED] transition-colors flex items-center gap-2 text-sm"
              >
                <Check size={14} />
                <span className="hidden sm:inline">Замовити</span>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Detailed price tables */}
      {tables.length > 0 && (
        <div className="bg-white rounded-xl card-shadow overflow-hidden">
          <div className="p-5 border-b border-gray-100 bg-gray-50 flex items-center justify-between flex-wrap gap-3">
            <h2 className="font-semibold text-gray-800">Детальний прайс-лист</h2>
            {tables.length > 1 && (
              <div className="flex gap-2">
                {tables.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedTable(idx)}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                      selectedTable === idx 
                        ? 'bg-[#8B5CF6] text-white' 
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    Таблиця {idx + 1}
                  </button>
                ))}
              </div>
            )}
          </div>
          
          {tables[selectedTable] && (
            <div>
              <div className="p-4 bg-[#F5F3FF] border-b border-[#EDE9FE]">
                <h3 className="font-semibold text-[#7C3AED]">{tables[selectedTable].name}</h3>
                <p className="text-sm text-gray-600">{tables[selectedTable].description}</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-50">
                      {tables[selectedTable].columns.map((col, idx) => (
                        <th key={idx} className="text-left p-4 font-semibold text-gray-700 text-sm">
                          {col}
                        </th>
                      ))}
                      <th className="p-4"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {tables[selectedTable].rows.map((row, idx) => (
                      <tr key={idx} className="hover:bg-gray-50">
                        <td className="p-4 font-medium text-gray-800">{row.service}</td>
                        {row.prices.map((price, pidx) => (
                          <td key={pidx} className="p-4 text-gray-600">{price}</td>
                        ))}
                        <td className="p-4 text-right">
                          <button 
                            onClick={() => onPageChange('create-order')}
                            className="text-[#8B5CF6] hover:underline text-sm font-medium"
                          >
                            Замовити
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* CTA */}
      <div className="bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] rounded-xl p-6 text-white text-center">
        <h2 className="text-xl font-bold mb-2">Потрібна консультація?</h2>
        <p className="text-white/80 mb-4 text-sm">Наші менеджери допоможуть підібрати потрібну послугу</p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button className="bg-white text-[#8B5CF6] px-5 py-2.5 rounded-lg font-medium hover:bg-gray-100 transition-colors flex items-center justify-center gap-2">
            <Phone size={16} />
            0 800 123 456
          </button>
          <button 
            onClick={() => onPageChange('create-order')}
            className="bg-[#6D28D9] text-white px-5 py-2.5 rounded-lg font-medium hover:bg-[#5B21B6] transition-colors flex items-center justify-center gap-2"
          >
            <MessageSquare size={16} />
            Створити завдання
          </button>
        </div>
      </div>
    </div>
  );
}
