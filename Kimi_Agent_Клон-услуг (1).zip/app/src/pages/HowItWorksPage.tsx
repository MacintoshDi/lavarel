import { Search, MessageSquare, CheckCircle, Star, Shield, Clock, Users } from 'lucide-react';

interface HowItWorksPageProps {
  onPageChange: (page: string, params?: any) => void;
}

export function HowItWorksPage({ onPageChange }: HowItWorksPageProps) {
  const steps = [
    {
      icon: Search,
      title: 'Знайдіть послугу',
      description: 'Оберіть потрібну категорію з понад 1000 послуг. Від ремонту до прибирання - у нас є все!',
      color: 'bg-[#8B5CF6]',
    },
    {
      icon: MessageSquare,
      title: 'Створіть завдання',
      description: 'Опишіть ваше завдання, вкажіть адресу, бажану дату та бюджет. Це займе всього 2 хвилини.',
      color: 'bg-[#A78BFA]',
    },
    {
      icon: CheckCircle,
      title: 'Отримайте пропозиції',
      description: 'Виконавці самі зв\'яжуться з вами зі своїми пропозиціями. Зазвичай перші відгуки надходять за 5 хвилин.',
      color: 'bg-[#C4B5FD]',
    },
    {
      icon: Star,
      title: 'Оберіть виконавця',
      description: 'Порівняйте ціни, відгуки та рейтинги. Оберіть найкращого виконавця для вашого завдання.',
      color: 'bg-[#DDD6FE]',
    },
  ];

  const benefits = [
    { icon: Shield, title: 'Перевірені виконавці', desc: 'Всі виконавці проходять верифікацію' },
    { icon: Clock, title: 'Економія часу', desc: 'Отримайте пропозиції за 5 хвилин' },
    { icon: Star, title: 'Чесні відгуки', desc: 'Реальні відгуки від реальних клієнтів' },
    { icon: Users, title: 'Підтримка 24/7', desc: 'Завжди на зв\'язку' },
  ];

  return (
    <div className="space-y-8 pb-8">
      {/* Hero */}
      <div className="bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] rounded-2xl p-8 text-center text-white">
        <h1 className="text-2xl lg:text-3xl font-bold mb-3">Як це працює</h1>
        <p className="text-white/80 max-w-xl mx-auto">
          Знайдіть надійного виконавця для будь-якої роботи за 4 простих кроки
        </p>
      </div>

      {/* Steps */}
      <div>
        <h2 className="text-xl font-bold text-gray-800 mb-6 text-center">4 кроки до результату</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div key={idx} className="bg-white rounded-xl p-5 card-shadow text-center">
                <div className={`w-14 h-14 ${step.color} rounded-xl flex items-center justify-center mx-auto mb-4`}>
                  <Icon className="text-white" size={26} />
                </div>
                <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-3 font-bold text-gray-600 text-sm">
                  {idx + 1}
                </div>
                <h3 className="font-semibold text-gray-800 mb-2">{step.title}</h3>
                <p className="text-sm text-gray-500">{step.description}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Benefits */}
      <div className="bg-white rounded-2xl card-shadow p-6 lg:p-8">
        <h2 className="text-xl font-bold text-gray-800 mb-6 text-center">Чому обирають нас</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit, idx) => {
            const Icon = benefit.icon;
            return (
              <div key={idx} className="text-center">
                <div className="w-12 h-12 bg-[#F5F3FF] rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Icon className="text-[#8B5CF6]" size={22} />
                </div>
                <h3 className="font-semibold text-gray-800 mb-1">{benefit.title}</h3>
                <p className="text-sm text-gray-500">{benefit.desc}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Stats */}
      <div className="bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] rounded-2xl p-6 lg:p-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center text-white">
          <div>
            <div className="text-3xl lg:text-4xl font-bold mb-1">50K+</div>
            <div className="text-white/70 text-sm">Виконавців</div>
          </div>
          <div>
            <div className="text-3xl lg:text-4xl font-bold mb-1">200K+</div>
            <div className="text-white/70 text-sm">Завдань</div>
          </div>
          <div>
            <div className="text-3xl lg:text-4xl font-bold mb-1">1K+</div>
            <div className="text-white/70 text-sm">Послуг</div>
          </div>
          <div>
            <div className="text-3xl lg:text-4xl font-bold mb-1">4.8</div>
            <div className="text-white/70 text-sm">Рейтинг</div>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="text-center bg-white rounded-2xl card-shadow p-8">
        <h2 className="text-xl font-bold text-gray-800 mb-3">Готові спробувати?</h2>
        <p className="text-gray-500 mb-6">Створіть перше завдання та переконайтесь у зручності сервісу</p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button 
            onClick={() => onPageChange('create-order')}
            className="bg-[#8B5CF6] text-white px-6 py-3 rounded-xl font-medium hover:bg-[#7C3AED] transition-colors"
          >
            Створити завдання
          </button>
          <button 
            onClick={() => onPageChange('categories')}
            className="bg-white text-[#8B5CF6] border border-[#8B5CF6] px-6 py-3 rounded-xl font-medium hover:bg-[#8B5CF6]/5 transition-colors"
          >
            Переглянути послуги
          </button>
        </div>
      </div>
    </div>
  );
}
