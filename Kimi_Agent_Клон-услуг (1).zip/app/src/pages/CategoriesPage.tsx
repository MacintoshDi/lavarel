import { useState } from 'react';
import { serviceCategories } from '@/data/servicesData';
import { ChevronRight, ArrowLeft, Search } from 'lucide-react';

interface CategoriesPageProps {
  onPageChange: (page: string, params?: any) => void;
  selectedCategory?: string;
}

export function CategoriesPage({ onPageChange, selectedCategory }: CategoriesPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedCategory, setExpandedCategory] = useState<string | null>(selectedCategory || null);

  const currentCategory = serviceCategories.find(c => c.id === expandedCategory);

  const filteredCategories = serviceCategories.filter(cat => 
    cat.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    cat.subcategories?.some(sub => 
      sub.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.services?.some(s => s.name.toLowerCase().includes(searchQuery.toLowerCase()))
    )
  );

  return (
    <div className="space-y-6 pb-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Всі послуги</h1>
          <p className="text-gray-500">Оберіть категорію та знайдіть потрібну послугу</p>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
        <input
          type="text"
          placeholder="Пошук послуг..."
          className="w-full pl-11 pr-4 py-3 bg-white rounded-xl border border-gray-200 focus:border-[#8B5CF6] transition-colors"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {/* Breadcrumb */}
      {currentCategory && (
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setExpandedCategory(null)}
            className="flex items-center gap-2 text-[#8B5CF6] hover:underline text-sm"
          >
            <ArrowLeft size={16} />
            <span>До всіх категорій</span>
          </button>
        </div>
      )}

      {/* Content */}
      {!currentCategory ? (
        // Categories list
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredCategories.map((category) => (
            <button
              key={category.id}
              onClick={() => setExpandedCategory(category.id)}
              className="bg-white rounded-xl p-5 card-shadow card-hover text-left group"
            >
              <div className="flex items-start gap-4">
                <div className="text-4xl">{category.icon}</div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-gray-800 group-hover:text-[#8B5CF6] transition-colors">
                      {category.name}
                    </h3>
                    <ChevronRight className="text-gray-300 group-hover:text-[#8B5CF6] transition-colors" size={18} />
                  </div>
                  <p className="text-sm text-gray-500 mt-1">{category.description}</p>
                  <div className="mt-3 text-xs text-gray-400">
                    {category.subcategories?.length || 0} підкатегорій
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      ) : (
        // Subcategories
        <div className="space-y-6">
          <div className="flex items-center gap-4">
            <div className="text-4xl">{currentCategory.icon}</div>
            <div>
              <h2 className="text-xl font-bold text-gray-800">{currentCategory.name}</h2>
              <p className="text-gray-500">{currentCategory.description}</p>
            </div>
          </div>

          <div className="grid gap-4">
            {currentCategory.subcategories?.map((sub) => (
              <div key={sub.id} className="bg-white rounded-xl card-shadow overflow-hidden">
                <div className="p-5 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="text-2xl">{sub.icon}</div>
                    <div>
                      <h3 className="font-semibold text-gray-800">{sub.name}</h3>
                      <p className="text-sm text-gray-500">{sub.description}</p>
                    </div>
                  </div>
                </div>
                <div className="divide-y divide-gray-100">
                  {sub.services?.map((service) => (
                    <button
                      key={service.id}
                      onClick={() => onPageChange('price-table', { 
                        categoryId: currentCategory.id,
                        subcategoryId: sub.id,
                        serviceId: service.id 
                      })}
                      className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-colors group"
                    >
                      <div className="text-left">
                        <div className="font-medium text-gray-800 group-hover:text-[#8B5CF6] transition-colors flex items-center gap-2">
                          {service.name}
                          {service.popular && (
                            <span className="bg-[#8B5CF6]/10 text-[#8B5CF6] text-xs px-2 py-0.5 rounded-full">
                              Популярне
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-gray-500">{service.description}</div>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <div className="font-semibold text-[#8B5CF6]">
                          {service.priceFrom && 'від '}{service.basePrice} грн
                        </div>
                        <div className="text-xs text-gray-400">{service.unit}</div>
                      </div>
                    </button>
                  ))}
                </div>
                <div className="p-4 bg-gray-50">
                  <button 
                    onClick={() => onPageChange('price-table', { 
                      categoryId: currentCategory.id,
                      subcategoryId: sub.id 
                    })}
                    className="text-[#8B5CF6] text-sm font-medium hover:underline"
                  >
                    Детальний прайс-лист →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
