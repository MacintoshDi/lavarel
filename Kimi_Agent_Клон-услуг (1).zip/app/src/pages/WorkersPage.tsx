import { workers, categories } from '@/data/mockData';
import { Star, MapPin, Phone, MessageSquare } from 'lucide-react';

interface WorkersPageProps {
  onPageChange: (page: string, params?: any) => void;
}

export function WorkersPage({ onPageChange }: WorkersPageProps) {
  return (
    <div className="min-h-screen bg-light">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Каталог майстрів і будівельних компаній</h1>
          <p className="text-gray-600 mt-2">Знайдіть надійного майстра для будь-яких робіт</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex gap-8">
          {/* Sidebar */}
          <div className="w-64 flex-shrink-0">
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
              <h3 className="font-bold mb-4">Категорії</h3>
              <ul className="space-y-2">
                {categories.slice(0, 8).map((cat) => (
                  <li key={cat.id}>
                    <button className="text-sm text-[#5b9bd5] hover:underline text-left">
                      {cat.name}
                    </button>
                  </li>
                ))}
              </ul>
              <button className="text-sm text-[#5b9bd5] mt-4 hover:underline">
                Показати всі (1361)
              </button>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-4">
              <h3 className="font-bold mb-4">Регіони</h3>
              <ul className="space-y-2">
                <li><button className="text-sm text-[#5b9bd5] hover:underline">Київ</button></li>
                <li><button className="text-sm text-[#5b9bd5] hover:underline">Львів</button></li>
                <li><button className="text-sm text-[#5b9bd5] hover:underline">Одеса</button></li>
                <li><button className="text-sm text-[#5b9bd5] hover:underline">Харків</button></li>
                <li><button className="text-sm text-[#5b9bd5] hover:underline">Дніпро</button></li>
              </ul>
            </div>
          </div>

          {/* Main content */}
          <div className="flex-1">
            <div className="bg-white rounded-lg shadow-sm p-4 mb-4 flex items-center justify-between">
              <span className="text-gray-600">Знайдено <strong>{workers.length}</strong> майстрів</span>
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-600">Сортування:</span>
                <select className="border rounded px-3 py-1 text-sm">
                  <option>За рейтингом</option>
                  <option>За відгуками</option>
                  <option>За датою реєстрації</option>
                </select>
              </div>
            </div>

            <div className="space-y-4">
              {workers.map((worker) => (
                <div key={worker.id} className="bg-white rounded-lg shadow-sm p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center text-4xl flex-shrink-0">
                      {worker.avatar}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 
                            className="text-lg font-medium text-[#5b9bd5] hover:underline cursor-pointer"
                            onClick={() => onPageChange('worker-profile', { id: worker.id })}
                          >
                            {worker.name}
                          </h3>
                          <div className="flex items-center gap-2 text-sm text-gray-500 mt-1">
                            <MapPin size={14} />
                            <span>{worker.location}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1 bg-green-50 px-3 py-1 rounded">
                          <Star size={16} className="text-yellow-500 fill-yellow-500" />
                          <span className="font-bold">{worker.rating}</span>
                          <span className="text-sm text-gray-500">({worker.reviews} відгуків)</span>
                        </div>
                      </div>

                      <p className="text-gray-600 text-sm mt-3 line-clamp-2">{worker.description}</p>

                      <div className="flex items-center gap-2 mt-3">
                        {worker.specialties.map((spec, idx) => (
                          <span key={idx} className="text-xs bg-gray-100 px-2 py-1 rounded text-gray-600">
                            {spec}
                          </span>
                        ))}
                      </div>

                      <div className="flex items-center gap-3 mt-4">
                        <button className="flex items-center gap-2 bg-[#5b9bd5] text-white px-4 py-2 rounded hover:bg-[#4a8ac4] transition-colors">
                          <Phone size={16} />
                          <span>Показати номер</span>
                        </button>
                        <button className="flex items-center gap-2 border border-[#5b9bd5] text-[#5b9bd5] px-4 py-2 rounded hover:bg-[#5b9bd5] hover:text-white transition-colors">
                          <MessageSquare size={16} />
                          <span>Написати</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
