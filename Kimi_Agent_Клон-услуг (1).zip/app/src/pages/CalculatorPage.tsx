import { useState } from 'react';
import { Wallpaper, FileText, AlertTriangle } from 'lucide-react';

interface CalculatorPageProps {
  onPageChange: (page: string, params?: any) => void;
}

export function CalculatorPage({ onPageChange }: CalculatorPageProps) {
  const [activeTab, setActiveTab] = useState<'wallpaper' | 'cost'>('wallpaper');

  return (
    <div className="min-h-screen bg-light">
      {/* Alert */}
      <div className="bg-yellow-50 border-b border-yellow-200">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center gap-3">
            <AlertTriangle className="text-yellow-600" size={24} />
            <p className="text-gray-700">
              <span className="font-bold">Увага!</span> Щоб зберегти результати розрахунків, Вам необхідно{' '}
              <button 
                onClick={() => onPageChange('signup')}
                className="text-[#5b9bd5] hover:underline"
              >
                зареєструватися
              </button>
              .
            </p>
          </div>
        </div>
      </div>

      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Будівельний калькулятор онлайн</h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Calculator options */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div 
            className={`bg-white rounded-lg shadow-sm overflow-hidden cursor-pointer transition-all ${
              activeTab === 'wallpaper' ? 'ring-2 ring-[#5b9bd5]' : ''
            }`}
            onClick={() => setActiveTab('wallpaper')}
          >
            <div className="bg-[#5b9bd5] text-white px-4 py-3 flex items-center justify-between">
              <span className="font-medium">Розрахунок кількості шпалер</span>
              <span className="bg-red-500 text-xs px-2 py-1 rounded">New</span>
            </div>
            <div className="p-6 text-center">
              <button className="bg-[#5b9bd5] text-white px-6 py-3 rounded flex items-center gap-2 mx-auto hover:bg-[#4a8ac4] transition-colors">
                <Wallpaper size={20} />
                <span>Розрахунок шпалер</span>
              </button>
            </div>
          </div>

          <div 
            className={`bg-white rounded-lg shadow-sm overflow-hidden cursor-pointer transition-all ${
              activeTab === 'cost' ? 'ring-2 ring-[#5b9bd5]' : ''
            }`}
            onClick={() => setActiveTab('cost')}
          >
            <div className="bg-[#5b9bd5] text-white px-4 py-3">
              <span className="font-medium">Розрахунок вартості ремонту</span>
            </div>
            <div className="p-6 text-center">
              <button className="bg-[#5b9bd5] text-white px-6 py-3 rounded flex items-center gap-2 mx-auto hover:bg-[#4a8ac4] transition-colors">
                <FileText size={20} />
                <span>Розрахунок вартості</span>
              </button>
            </div>
          </div>
        </div>

        {/* Info section */}
        <div className="bg-white rounded-lg shadow-sm p-8">
          <h2 className="text-xl font-bold mb-4">Будівельний калькулятор онлайн</h2>
          
          <div className="prose max-w-none text-gray-700">
            <p className="mb-4">
              Калькулятор ремонту онлайн це дійсно проста і дуже зручна послуга. Ми переконані, 
              що вона вам стане в нагоді при будь-яких будівельних роботах. Калькулятор ремонту 
              працює дуже просто: ви вказуєте площу вашого приміщення або окремої його частини 
              і калькулятор ремонту квартири практично моментально складає кошторис робіт на 
              підставі <strong>сьогоднішніх середніх цін по країні</strong>.
            </p>
            
            <p className="mb-4">
              Ціни вважаються на підставі прайс-листів 50 000 будівельників. Нічого більш точного 
              в Україні немає. Після розрахунку ви зможете дізнатися заздалегідь, яку приблизно 
              суму вам доведеться витратити на необхідні роботи. Якщо ви сумніваєтеся в якихось 
              будівельних рішеннях, калькулятор вартості ремонту квартири допоможе вам визначитися.
            </p>
            
            <p className="mb-6">
              Особливо ця послуга буде корисна для тих, хто збирається робити капітальний ремонт 
              квартири або приміщення. Калькулятор нашого сервісу зможе прорахувати всю вартість 
              робіт до дрібниць.
            </p>

            <h3 className="text-lg font-bold mb-3">Які є можливості при розрахунку ремонту</h3>
            
            <ol className="list-decimal list-inside space-y-2 mb-6">
              <li>Зберегти розрахунок і зберігати необмежену кількість розрахунків в будь-який час.</li>
              <li>Надрукувати його в різних форматах.</li>
              <li>Розбити звіт на кілька сторінок (кожна на окремий фронт або період роботи)</li>
              <li>Давати розрахунку і сторінкам назви, щоб рахунки виглядала красиво.</li>
            </ol>

            <p className="mb-4">
              У нас є додаткові послуги: прорахунок вартості перевезень і прибирання приміщень. 
              Сервіс покаже вам поточні середні ціни на ці види робіт.
            </p>

            <p className="mb-4">
              Ми аналізуємо і міняємо ціни на будівельні роботи щогодини, тому наш розрахунок 
              буде максимально точним. Ми вас запевняємо, наш калькулятор ремонту вам точно 
              стане в нагоді. Велика кількість бажаючих зробити ремонтні роботи вже випробували 
              цю послугу (більше 200 000 розрахунків), тепер прийшов Ваш час перевірити, як 
              працює калькулятор розрахунку вартості ремонту квартири, і ви переконаєтеся, що 
              це незамінна річ.
            </p>

            <p>
              На нашому ресурсі <strong>Rabotniki.UA</strong> є багато варіантів застосування 
              кошторисного калькулятора. Ви можете використовувати його для розрахунку ремонту 
              в новобудові або для ремонту ванної, балкона, коридору і так далі. Тобто калькулятор 
              ремонту квартири ніяким чином не обмежує вас в масштабах. Він дозволить вам 
              власноруч розрахувати вартість робіт, як в комплексі, так і по окремих видах 
              оздоблювальних і ремонтних робіт.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
