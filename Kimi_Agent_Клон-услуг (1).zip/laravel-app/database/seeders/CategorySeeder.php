<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\PriceTable;
use App\Models\Service;
use App\Models\Subcategory;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            [
                'name' => 'Ремонт та будівництво',
                'slug' => 'remont',
                'icon' => '🔨',
                'description' => 'Ремонт квартир, будинків, офісів та комерційних приміщень',
                'subcategories' => [
                    [
                        'name' => 'Ремонт квартири',
                        'slug' => 'remont-kvartiry',
                        'icon' => '🏠',
                        'description' => 'Косметичний, капітальний та євроремонт квартир',
                        'services' => [
                            ['name' => 'Косметичний ремонт', 'slug' => 'kosmeticheskiy', 'description' => 'Фарбування стін, заміна ламінату, оновлення сантехніки', 'base_price' => 3500, 'unit' => 'м²', 'price_from' => true, 'popular' => true],
                            ['name' => 'Капітальний ремонт', 'slug' => 'kapitalnyy', 'description' => 'Повна заміна всіх комунікацій, перепланування, чорнові роботи', 'base_price' => 5500, 'unit' => 'м²', 'price_from' => true, 'popular' => true],
                            ['name' => 'Євроремонт', 'slug' => 'evroremont', 'description' => 'Дизайнерський ремонт з використанням преміум матеріалів', 'base_price' => 8500, 'unit' => 'м²', 'price_from' => true, 'popular' => false],
                            ['name' => 'Ремонт студії', 'slug' => 'studiya', 'description' => 'Ремонт однокімнатної квартири-студії', 'base_price' => 4500, 'unit' => 'м²', 'price_from' => true, 'popular' => false],
                        ],
                        'price_tables' => [
                            [
                                'name' => 'Косметичний ремонт - детальний прайс',
                                'description' => 'Ціни на окремі види робіт при косметичному ремонті',
                                'columns' => ['Вид роботи', 'Одиниця', 'Ціна від, грн'],
                                'rows' => [
                                    ['service' => 'Фарбування стін', 'prices' => ['м²', '60']],
                                    ['service' => 'Фарбування стелі', 'prices' => ['м²', '80']],
                                    ['service' => 'Поклейка шпалер (паперові)', 'prices' => ['м²', '80']],
                                    ['service' => 'Поклейка шпалер (вінілові/флізелін)', 'prices' => ['м²', '100']],
                                    ['service' => 'Укладання ламінату', 'prices' => ['м²', '120']],
                                    ['service' => 'Укладання лінолеуму', 'prices' => ['м²', '80']],
                                    ['service' => 'Заміна плінтуса', 'prices' => ['м.п.', '40']],
                                    ['service' => 'Установка дверей', 'prices' => ['за шт', '800']],
                                ],
                            ],
                            [
                                'name' => 'Капітальний ремонт - детальний прайс',
                                'description' => 'Ціни на окремі види робіт при капітальному ремонті',
                                'columns' => ['Вид роботи', 'Одиниця', 'Ціна від, грн'],
                                'rows' => [
                                    ['service' => 'Демонтаж стін', 'prices' => ['м²', '150']],
                                    ['service' => 'Демонтаж підлоги', 'prices' => ['м²', '80']],
                                    ['service' => 'Демонтаж стелі', 'prices' => ['м²', '100']],
                                    ['service' => 'Штукатурка стін', 'prices' => ['м²', '280']],
                                    ['service' => 'Штукатурка стелі', 'prices' => ['м²', '350']],
                                    ['service' => 'Стяжка підлоги', 'prices' => ['м²', '180']],
                                    ['service' => 'Електропроводка (нова)', 'prices' => ['м.п.', '150']],
                                    ['service' => 'Заміна труб водопостачання', 'prices' => ['м.п.', '300']],
                                    ['service' => 'Укладання плитки (стіни)', 'prices' => ['м²', '450']],
                                    ['service' => 'Укладання плитки (підлога)', 'prices' => ['м²', '400']],
                                ],
                            ],
                        ],
                    ],
                    [
                        'name' => 'Ремонт кімнат',
                        'slug' => 'remont-komnaty',
                        'icon' => '🚪',
                        'description' => 'Ремонт окремих кімнат та приміщень',
                        'services' => [
                            ['name' => 'Ремонт кухні', 'slug' => 'kuhnya-remont', 'description' => 'Повний ремонт кухні з заміною сантехніки та електрики', 'base_price' => 25000, 'unit' => 'за кімнату', 'price_from' => true, 'popular' => true],
                            ['name' => 'Ремонт ванної кімнати', 'slug' => 'vannaya-remont', 'description' => 'Ремонт санвузла під ключ', 'base_price' => 18000, 'unit' => 'за кімнату', 'price_from' => true, 'popular' => true],
                            ['name' => 'Ремонт спальні', 'slug' => 'spalnya-remont', 'description' => 'Ремонт спальної кімнати', 'base_price' => 15000, 'unit' => 'за кімнату', 'price_from' => true, 'popular' => false],
                            ['name' => 'Ремонт вітальні', 'slug' => 'gostinaya-remont', 'description' => 'Ремонт вітальні кімнати', 'base_price' => 20000, 'unit' => 'за кімнату', 'price_from' => true, 'popular' => false],
                        ],
                        'price_tables' => [],
                    ],
                    [
                        'name' => 'Будівництво',
                        'slug' => 'stroitelstvo',
                        'icon' => '🏗️',
                        'description' => 'Будівництво будинків, котеджів, гаражів',
                        'services' => [
                            ['name' => 'Каркасний будинок', 'slug' => 'dom-karkasnyy', 'description' => 'Будівництво каркасного будинку', 'base_price' => 8000, 'unit' => 'м²', 'price_from' => true, 'popular' => false],
                            ['name' => 'Цегляний будинок', 'slug' => 'dom-kirpich', 'description' => 'Будівництво будинку з цегли', 'base_price' => 12000, 'unit' => 'м²', 'price_from' => true, 'popular' => false],
                            ['name' => 'Гараж', 'slug' => 'garazh', 'description' => 'Будівництво гаража', 'base_price' => 3500, 'unit' => 'м²', 'price_from' => true, 'popular' => false],
                            ['name' => 'Альтанка/бесідка', 'slug' => 'besedka', 'description' => 'Будівництво дерев\'яної альтанки', 'base_price' => 15000, 'unit' => 'за об\'єкт', 'price_from' => true, 'popular' => false],
                        ],
                        'price_tables' => [],
                    ],
                    [
                        'name' => 'Оздоблювальні роботи',
                        'slug' => 'otdelochnye',
                        'icon' => '🎨',
                        'description' => 'Штукатурка, шпаклівка, фарбування, обої',
                        'services' => [
                            ['name' => 'Штукатурка стін', 'slug' => 'shtukaturka', 'description' => 'Машинна та ручна штукатурка', 'base_price' => 280, 'unit' => 'м²', 'price_from' => true, 'popular' => true],
                            ['name' => 'Шпаклівка стін', 'slug' => 'shpaklevka', 'description' => 'Шпаклівка під фарбування або обої', 'base_price' => 120, 'unit' => 'м²', 'price_from' => true, 'popular' => false],
                            ['name' => 'Фарбування стін', 'slug' => 'pokraska', 'description' => 'Фарбування стін та стель', 'base_price' => 80, 'unit' => 'м²', 'price_from' => true, 'popular' => false],
                            ['name' => 'Поклейка шпалер', 'slug' => 'oboi', 'description' => 'Поклейка шпалер всіх видів', 'base_price' => 100, 'unit' => 'м²', 'price_from' => true, 'popular' => true],
                        ],
                        'price_tables' => [],
                    ],
                ],
            ],
            [
                'name' => 'Сантехніка',
                'slug' => 'santehnika',
                'icon' => '🚿',
                'description' => 'Установка сантехніки, ремонт труб, системи опалення',
                'subcategories' => [
                    [
                        'name' => 'Установка сантехніки',
                        'slug' => 'ustanovka-santehniki',
                        'icon' => '🚽',
                        'description' => 'Монтаж сантехнічних приладів',
                        'services' => [
                            ['name' => 'Установка унітазу', 'slug' => 'unitaz', 'description' => 'Монтаж унітазу з підключенням', 'base_price' => 800, 'unit' => 'за шт', 'price_from' => true, 'popular' => true],
                            ['name' => 'Установка раковини', 'slug' => 'rakovina', 'description' => 'Монтаж раковини/умивальника', 'base_price' => 600, 'unit' => 'за шт', 'price_from' => true, 'popular' => false],
                            ['name' => 'Установка ванни', 'slug' => 'vanna', 'description' => 'Монтаж ванни (акрил, чавун, сталь)', 'base_price' => 1500, 'unit' => 'за шт', 'price_from' => true, 'popular' => true],
                            ['name' => 'Установка душової кабіни', 'slug' => 'dush-kabina', 'description' => 'Монтаж душової кабіни/боксу', 'base_price' => 2500, 'unit' => 'за шт', 'price_from' => true, 'popular' => false],
                            ['name' => 'Установка змішувача', 'slug' => 'smesitel', 'description' => 'Заміна/монтаж змішувача', 'base_price' => 400, 'unit' => 'за шт', 'price_from' => true, 'popular' => false],
                        ],
                        'price_tables' => [
                            [
                                'name' => 'Прайс на сантехнічні роботи',
                                'description' => 'Вартість установки та заміни сантехніки',
                                'columns' => ['Послуга', 'Одиниця', 'Ціна від, грн'],
                                'rows' => [
                                    ['service' => 'Установка унітазу (навісний)', 'prices' => ['за шт', '1000']],
                                    ['service' => 'Установка унітазу (компакт)', 'prices' => ['за шт', '800']],
                                    ['service' => 'Установка інсталяції', 'prices' => ['за шт', '1500']],
                                    ['service' => 'Установка раковини (тюльпан)', 'prices' => ['за шт', '600']],
                                    ['service' => 'Установка раковини (підвісна)', 'prices' => ['за шт', '800']],
                                    ['service' => 'Установка ванни (акрил)', 'prices' => ['за шт', '1500']],
                                    ['service' => 'Установка ванни (чавун)', 'prices' => ['за шт', '2000']],
                                    ['service' => 'Установка душової кабіни', 'prices' => ['за шт', '2500']],
                                    ['service' => 'Установка змішувача', 'prices' => ['за шт', '400']],
                                    ['service' => 'Установка бойлера', 'prices' => ['за шт', '1200']],
                                    ['service' => 'Прочистка каналізації', 'prices' => ['за точку', '500']],
                                ],
                            ],
                        ],
                    ],
                    [
                        'name' => 'Ремонт сантехніки',
                        'slug' => 'santeh-remont',
                        'icon' => '🔧',
                        'description' => 'Ремонт та усунення несправностей',
                        'services' => [
                            ['name' => 'Прочистка каналізації', 'slug' => 'prochistka-kanalyzatsii', 'description' => 'Чистка засмічень у трубах', 'base_price' => 500, 'unit' => 'за точку', 'price_from' => true, 'popular' => true],
                            ['name' => 'Заміна труб', 'slug' => 'zamena-trub', 'description' => 'Заміна старих труб на нові', 'base_price' => 300, 'unit' => 'м.п.', 'price_from' => true, 'popular' => false],
                            ['name' => 'Усунення витоку', 'slug' => 'ustranenie-techni', 'description' => 'Пошук та усунення витоку води', 'base_price' => 400, 'unit' => 'за роботу', 'price_from' => true, 'popular' => false],
                        ],
                        'price_tables' => [],
                    ],
                    [
                        'name' => 'Опалення',
                        'slug' => 'otoplenie',
                        'icon' => '🔥',
                        'description' => 'Монтаж систем опалення',
                        'services' => [
                            ['name' => 'Монтаж котла', 'slug' => 'montazh-kotla', 'description' => 'Установка газового/електро котла', 'base_price' => 3500, 'unit' => 'за шт', 'price_from' => true, 'popular' => false],
                            ['name' => 'Установка радіаторів', 'slug' => 'radiatory', 'description' => 'Монтаж батарей опалення', 'base_price' => 800, 'unit' => 'за шт', 'price_from' => true, 'popular' => false],
                            ['name' => 'Тепла підлога', 'slug' => 'teplyy-pol', 'description' => 'Монтаж електричної теплої підлоги', 'base_price' => 450, 'unit' => 'м²', 'price_from' => true, 'popular' => false],
                        ],
                        'price_tables' => [],
                    ],
                ],
            ],
            [
                'name' => 'Електрика',
                'slug' => 'elektrika',
                'icon' => '⚡',
                'description' => 'Електромонтажні роботи, заміна проводки, установка розеток',
                'subcategories' => [
                    [
                        'name' => 'Електромонтаж',
                        'slug' => 'elektro-montazh',
                        'icon' => '🔌',
                        'description' => 'Монтаж електрообладнання',
                        'services' => [
                            ['name' => 'Заміна проводки', 'slug' => 'zamena-provodki', 'description' => 'Повна або часткова заміна електропроводки', 'base_price' => 150, 'unit' => 'м.п.', 'price_from' => true, 'popular' => true],
                            ['name' => 'Установка розетки', 'slug' => 'rozetka', 'description' => 'Монтаж/заміна розетки', 'base_price' => 150, 'unit' => 'за шт', 'price_from' => true, 'popular' => false],
                            ['name' => 'Установка вимикача', 'slug' => 'vychyklyatel', 'description' => 'Монтаж/заміна вимикача', 'base_price' => 150, 'unit' => 'за шт', 'price_from' => true, 'popular' => false],
                            ['name' => 'Установка люстри', 'slug' => 'lyustra', 'description' => 'Монтаж освітлювального приладу', 'base_price' => 300, 'unit' => 'за шт', 'price_from' => true, 'popular' => true],
                            ['name' => 'Монтаж електрощита', 'slug' => 'elektroshchit', 'description' => 'Установка та підключення щита', 'base_price' => 1200, 'unit' => 'за шт', 'price_from' => true, 'popular' => false],
                        ],
                        'price_tables' => [
                            [
                                'name' => 'Прайс на електромонтажні роботи',
                                'description' => 'Вартість електромонтажних робіт',
                                'columns' => ['Послуга', 'Одиниця', 'Ціна від, грн'],
                                'rows' => [
                                    ['service' => 'Штроблення стін під проводку', 'prices' => ['м.п.', '50']],
                                    ['service' => 'Прокладання кабелю', 'prices' => ['м.п.', '30']],
                                    ['service' => 'Установка розетки/вимикача', 'prices' => ['за шт', '150']],
                                    ['service' => 'Установка розетки (з штробленням)', 'prices' => ['за шт', '300']],
                                    ['service' => 'Установка люстри (проста)', 'prices' => ['за шт', '300']],
                                    ['service' => 'Установка люстри (складна)', 'prices' => ['за шт', '600']],
                                    ['service' => 'Установка світильника точкового', 'prices' => ['за шт', '200']],
                                    ['service' => 'Монтаж електрощита', 'prices' => ['за шт', '1200']],
                                    ['service' => 'Установка автомата', 'prices' => ['за шт', '200']],
                                    ['service' => 'Заміна проводки (квартира 1-кімн)', 'prices' => ['за об\'єкт', '8000']],
                                ],
                            ],
                        ],
                    ],
                    [
                        'name' => 'Ремонт електрики',
                        'slug' => 'elektro-remont',
                        'icon' => '🔧',
                        'description' => 'Діагностика та ремонт',
                        'services' => [
                            ['name' => 'Діагностика електрики', 'slug' => 'diagnostyka', 'description' => 'Пошук несправностей у проводці', 'base_price' => 500, 'unit' => 'за виїзд', 'price_from' => true, 'popular' => false],
                            ['name' => 'Заміна автомата', 'slug' => 'zamena-avtomata', 'description' => 'Заміна запобіжника/автомата', 'base_price' => 200, 'unit' => 'за шт', 'price_from' => true, 'popular' => false],
                        ],
                        'price_tables' => [],
                    ],
                ],
            ],
            [
                'name' => 'Прибирання',
                'slug' => 'uborka',
                'icon' => '🧹',
                'description' => 'Генеральне прибирання, прибирання після ремонту, миття вікон',
                'subcategories' => [
                    [
                        'name' => 'Прибирання квартири',
                        'slug' => 'uborka-kvartiry',
                        'icon' => '🏠',
                        'description' => 'Різні види прибирання',
                        'services' => [
                            ['name' => 'Підтримуюче прибирання', 'slug' => 'podderzhivayushchaya', 'description' => 'Регулярне прибирання квартири', 'base_price' => 800, 'unit' => 'за кімнату', 'price_from' => true, 'popular' => true],
                            ['name' => 'Генеральне прибирання', 'slug' => 'generalnaya', 'description' => 'Глибоке прибирання всіх приміщень', 'base_price' => 1500, 'unit' => 'за кімнату', 'price_from' => true, 'popular' => true],
                            ['name' => 'Прибирання після ремонту', 'slug' => 'posle-remonta', 'description' => 'Прибирання будівельного пилу та сміття', 'base_price' => 2500, 'unit' => 'за кімнату', 'price_from' => true, 'popular' => false],
                        ],
                        'price_tables' => [],
                    ],
                    [
                        'name' => 'Миття',
                        'slug' => 'moyka',
                        'icon' => '💧',
                        'description' => 'Миття вікон та інших поверхонь',
                        'services' => [
                            ['name' => 'Миття вікон', 'slug' => 'moyka-okon', 'description' => 'Миття вікон з обох сторін', 'base_price' => 150, 'unit' => 'за м²', 'price_from' => true, 'popular' => true],
                            ['name' => 'Миття балкона', 'slug' => 'moyka-balkona', 'description' => 'Миття вікон та рам на балконі', 'base_price' => 500, 'unit' => 'за балкон', 'price_from' => true, 'popular' => false],
                        ],
                        'price_tables' => [],
                    ],
                ],
            ],
            [
                'name' => 'Вантажники та переїзди',
                'slug' => 'gruzchiki',
                'icon' => '📦',
                'description' => 'Вантажні роботи, переїзди, вивіз сміття',
                'subcategories' => [
                    [
                        'name' => 'Вантажоперевезення',
                        'slug' => 'gruzoperevozki',
                        'icon' => '🚚',
                        'description' => 'Перевезення речей',
                        'services' => [
                            ['name' => 'Вантажник (погодинно)', 'slug' => 'gruzchik-chas', 'description' => 'Вантажник за годину роботи', 'base_price' => 250, 'unit' => 'за год', 'price_from' => true, 'popular' => true],
                            ['name' => 'Квартирний переїзд', 'slug' => 'pereezd-kvartira', 'description' => 'Переїзд зі збором/розбором меблів', 'base_price' => 2500, 'unit' => 'за переїзд', 'price_from' => true, 'popular' => false],
                            ['name' => 'Офісний переїзд', 'slug' => 'pereezd-ofis', 'description' => 'Переїзд офісу з технікою', 'base_price' => 5000, 'unit' => 'за переїзд', 'price_from' => true, 'popular' => false],
                        ],
                        'price_tables' => [],
                    ],
                    [
                        'name' => 'Вивіз сміття',
                        'slug' => 'vyvoz-musora',
                        'icon' => '🗑️',
                        'description' => 'Вивезення сміття та старих речей',
                        'services' => [
                            ['name' => 'Вивіз будівельного сміття', 'slug' => 'vyvoz-stroymusora', 'description' => 'Вивіз сміття після ремонту', 'base_price' => 1500, 'unit' => 'за рейс', 'price_from' => true, 'popular' => false],
                            ['name' => 'Вивіз старих меблів', 'slug' => 'vyvoz-mebeli', 'description' => 'Вивезення та утилізація меблів', 'base_price' => 800, 'unit' => 'за шт', 'price_from' => true, 'popular' => false],
                        ],
                        'price_tables' => [],
                    ],
                ],
            ],
            [
                'name' => 'Меблі та збірка',
                'slug' => 'mebel',
                'icon' => '🪑',
                'description' => 'Збірка меблів, ремонт меблів, виготовлення на замовлення',
                'subcategories' => [
                    [
                        'name' => 'Збірка меблів',
                        'slug' => 'sborka-mebeli',
                        'icon' => '🔧',
                        'description' => 'Збірка різних типів меблів',
                        'services' => [
                            ['name' => 'Збірка шафи', 'slug' => 'sborka-shkaf', 'description' => 'Збірка шафи-купе або розпашної', 'base_price' => 800, 'unit' => 'за шт', 'price_from' => true, 'popular' => true],
                            ['name' => 'Збірка ліжка', 'slug' => 'sborka-krovat', 'description' => 'Збірка ліжка з матрацом', 'base_price' => 500, 'unit' => 'за шт', 'price_from' => true, 'popular' => false],
                            ['name' => 'Збірка столу', 'slug' => 'sborka-stol', 'description' => 'Збірка обіднього/письмового столу', 'base_price' => 400, 'unit' => 'за шт', 'price_from' => true, 'popular' => false],
                            ['name' => 'Збірка комода', 'slug' => 'sborka-komod', 'description' => 'Збірка комода/тумби', 'base_price' => 350, 'unit' => 'за шт', 'price_from' => true, 'popular' => false],
                            ['name' => 'Збірка кухні', 'slug' => 'sborka-kuhnya', 'description' => 'Збірка кухонного гарнітура', 'base_price' => 2500, 'unit' => 'за комплект', 'price_from' => true, 'popular' => true],
                        ],
                        'price_tables' => [],
                    ],
                ],
            ],
            [
                'name' => 'Сад та город',
                'slug' => 'sad',
                'icon' => '🌳',
                'description' => 'Догляд за садом, обрізка дерев, покос трави',
                'subcategories' => [
                    [
                        'name' => 'Догляд за садом',
                        'slug' => 'uhod-sad',
                        'icon' => '🌿',
                        'description' => 'Роботи по догляду за садом',
                        'services' => [
                            ['name' => 'Покіс трави', 'slug' => 'pokos-travy', 'description' => 'Стрижка газону триммером/газонокосаркою', 'base_price' => 80, 'unit' => 'за сотку', 'price_from' => true, 'popular' => true],
                            ['name' => 'Обрізка дерев', 'slug' => 'obrezka-dereviev', 'description' => 'Обрізка плодових та декоративних дерев', 'base_price' => 500, 'unit' => 'за дерево', 'price_from' => true, 'popular' => false],
                            ['name' => 'Прибирання листя', 'slug' => 'uborka-listev', 'description' => 'Збір та вивіз опалого листя', 'base_price' => 300, 'unit' => 'за сотку', 'price_from' => true, 'popular' => false],
                        ],
                        'price_tables' => [],
                    ],
                ],
            ],
        ];

        foreach ($categories as $catData) {
            $category = Category::create([
                'name' => $catData['name'],
                'slug' => $catData['slug'],
                'icon' => $catData['icon'],
                'description' => $catData['description'],
                'sort_order' => 0,
                'is_active' => true,
            ]);

            foreach ($catData['subcategories'] as $subIndex => $subData) {
                $subcategory = Subcategory::create([
                    'category_id' => $category->id,
                    'name' => $subData['name'],
                    'slug' => $subData['slug'],
                    'icon' => $subData['icon'],
                    'description' => $subData['description'],
                    'sort_order' => $subIndex,
                    'is_active' => true,
                ]);

                foreach ($subData['services'] as $servIndex => $servData) {
                    Service::create([
                        'subcategory_id' => $subcategory->id,
                        'name' => $servData['name'],
                        'slug' => $servData['slug'],
                        'description' => $servData['description'],
                        'base_price' => $servData['base_price'],
                        'unit' => $servData['unit'],
                        'price_from' => $servData['price_from'],
                        'popular' => $servData['popular'],
                        'sort_order' => $servIndex,
                        'is_active' => true,
                    ]);
                }

                foreach ($subData['price_tables'] as $tableIndex => $tableData) {
                    PriceTable::create([
                        'subcategory_id' => $subcategory->id,
                        'name' => $tableData['name'],
                        'description' => $tableData['description'],
                        'columns' => $tableData['columns'],
                        'rows' => $tableData['rows'],
                        'sort_order' => $tableIndex,
                        'is_active' => true,
                    ]);
                }
            }
        }
    }
}
