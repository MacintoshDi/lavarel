<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // Admin user
        User::create([
            'name' => 'Адміністратор',
            'email' => 'admin@servis.ua',
            'phone' => '+380501234567',
            'password' => Hash::make('password'),
            'role' => User::ROLE_ADMIN,
            'is_active' => true,
        ]);

        // Demo customer
        User::create([
            'name' => 'Тестовий Користувач',
            'email' => 'user@servis.ua',
            'phone' => '+380507654321',
            'password' => Hash::make('password'),
            'role' => User::ROLE_CUSTOMER,
            'is_active' => true,
        ]);
    }
}
