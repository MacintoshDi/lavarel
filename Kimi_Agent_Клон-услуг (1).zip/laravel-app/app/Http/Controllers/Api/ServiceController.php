<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Models\Subcategory;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Service::active()->with('subcategory.category');

        if ($request->has('subcategory_id')) {
            $query->where('subcategory_id', $request->subcategory_id);
        }

        if ($request->has('popular')) {
            $query->popular();
        }

        $services = $query->orderBy('sort_order')->get();

        return response()->json([
            'success' => true,
            'data' => $services,
        ]);
    }

    public function show($id): JsonResponse
    {
        $service = Service::with('subcategory.category')->findOrFail($id);

        return response()->json([
            'success' => true,
            'data' => $service,
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'subcategory_id' => 'required|exists:subcategories,id',
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255',
            'description' => 'nullable|string',
            'base_price' => 'required|numeric|min:0',
            'unit' => 'required|string|max:50',
            'price_from' => 'nullable|boolean',
            'popular' => 'nullable|boolean',
            'sort_order' => 'nullable|integer',
            'is_active' => 'nullable|boolean',
        ]);

        $service = Service::create($validated);

        return response()->json([
            'success' => true,
            'data' => $service,
            'message' => 'Послугу створено успішно',
        ], 201);
    }

    public function update(Request $request, $id): JsonResponse
    {
        $service = Service::findOrFail($id);

        $validated = $request->validate([
            'subcategory_id' => 'sometimes|exists:subcategories,id',
            'name' => 'sometimes|string|max:255',
            'slug' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
            'base_price' => 'sometimes|numeric|min:0',
            'unit' => 'sometimes|string|max:50',
            'price_from' => 'nullable|boolean',
            'popular' => 'nullable|boolean',
            'sort_order' => 'nullable|integer',
            'is_active' => 'nullable|boolean',
        ]);

        $service->update($validated);

        return response()->json([
            'success' => true,
            'data' => $service,
            'message' => 'Послугу оновлено успішно',
        ]);
    }

    public function destroy($id): JsonResponse
    {
        $service = Service::findOrFail($id);
        $service->delete();

        return response()->json([
            'success' => true,
            'message' => 'Послугу видалено успішно',
        ]);
    }

    public function getPriceTable($subcategoryId): JsonResponse
    {
        $subcategory = Subcategory::with(['priceTables' => function ($query) {
            $query->active()->orderBy('sort_order');
        }, 'services'])->findOrFail($subcategoryId);

        return response()->json([
            'success' => true,
            'data' => [
                'subcategory' => $subcategory,
                'price_tables' => $subcategory->priceTables,
                'services' => $subcategory->services,
            ],
        ]);
    }
}
