<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Order::with(['service', 'category', 'subcategory']);

        // Фильтр по пользователю (если не админ)
        if (!Auth::user()?->isAdmin()) {
            $query->forUser(Auth::id());
        }

        // Фильтр по статусу
        if ($request->has('status')) {
            $query->byStatus($request->status);
        }

        // Поиск
        if ($request->has('search')) {
            $query->where('title', 'like', '%' . $request->search . '%');
        }

        $orders = $query->orderByDesc('created_at')->get();

        return response()->json([
            'success' => true,
            'data' => $orders,
        ]);
    }

    public function show($id): JsonResponse
    {
        $order = Order::with(['service', 'category', 'subcategory', 'responses'])->findOrFail($id);

        // Проверка прав доступа
        if (!Auth::user()?->isAdmin() && $order->user_id !== Auth::id()) {
            return response()->json([
                'success' => false,
                'message' => 'Доступ заборонено',
            ], 403);
        }

        return response()->json([
            'success' => true,
            'data' => $order,
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'service_id' => 'nullable|exists:services,id',
            'category_id' => 'nullable|exists:categories,id',
            'subcategory_id' => 'nullable|exists:subcategories,id',
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'address' => 'required|string',
            'scheduled_date' => 'required|date',
            'scheduled_time' => 'required',
            'budget' => 'nullable|numeric|min:0',
        ]);

        $validated['user_id'] = Auth::id();
        $validated['status'] = Order::STATUS_NEW;

        $order = Order::create($validated);

        return response()->json([
            'success' => true,
            'data' => $order,
            'message' => 'Завдання створено успішно',
        ], 201);
    }

    public function update(Request $request, $id): JsonResponse
    {
        $order = Order::findOrFail($id);

        // Проверка прав доступа
        if (!Auth::user()?->isAdmin() && $order->user_id !== Auth::id()) {
            return response()->json([
                'success' => false,
                'message' => 'Доступ заборонено',
            ], 403);
        }

        $validated = $request->validate([
            'title' => 'sometimes|string|max:255',
            'description' => 'sometimes|string',
            'address' => 'sometimes|string',
            'scheduled_date' => 'sometimes|date',
            'scheduled_time' => 'sometimes',
            'budget' => 'nullable|numeric|min:0',
            'status' => 'sometimes|in:new,in_progress,completed,cancelled',
        ]);

        $order->update($validated);

        return response()->json([
            'success' => true,
            'data' => $order,
            'message' => 'Завдання оновлено успішно',
        ]);
    }

    public function destroy($id): JsonResponse
    {
        $order = Order::findOrFail($id);

        // Проверка прав доступа
        if (!Auth::user()?->isAdmin() && $order->user_id !== Auth::id()) {
            return response()->json([
                'success' => false,
                'message' => 'Доступ заборонено',
            ], 403);
        }

        $order->delete();

        return response()->json([
            'success' => true,
            'message' => 'Завдання видалено успішно',
        ]);
    }

    public function myOrders(): JsonResponse
    {
        $orders = Order::forUser(Auth::id())
            ->with(['service', 'category', 'subcategory'])
            ->orderByDesc('created_at')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $orders,
        ]);
    }

    public function stats(): JsonResponse
    {
        $userId = Auth::id();

        $stats = [
            'total' => Order::forUser($userId)->count(),
            'new' => Order::forUser($userId)->byStatus(Order::STATUS_NEW)->count(),
            'in_progress' => Order::forUser($userId)->byStatus(Order::STATUS_IN_PROGRESS)->count(),
            'completed' => Order::forUser($userId)->byStatus(Order::STATUS_COMPLETED)->count(),
        ];

        return response()->json([
            'success' => true,
            'data' => $stats,
        ]);
    }
}
