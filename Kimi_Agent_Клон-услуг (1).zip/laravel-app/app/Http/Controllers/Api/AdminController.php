<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Order;
use App\Models\Service;
use App\Models\Subcategory;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function dashboard(): JsonResponse
    {
        $stats = [
            'users' => [
                'total' => User::count(),
                'customers' => User::customers()->count(),
                'admins' => User::admins()->count(),
                'new_today' => User::whereDate('created_at', today())->count(),
            ],
            'orders' => [
                'total' => Order::count(),
                'new' => Order::byStatus(Order::STATUS_NEW)->count(),
                'in_progress' => Order::byStatus(Order::STATUS_IN_PROGRESS)->count(),
                'completed' => Order::byStatus(Order::STATUS_COMPLETED)->count(),
                'today' => Order::whereDate('created_at', today())->count(),
            ],
            'services' => [
                'categories' => Category::count(),
                'subcategories' => Subcategory::count(),
                'services' => Service::count(),
                'popular' => Service::popular()->count(),
            ],
        ];

        $recentOrders = Order::with('user')
            ->orderByDesc('created_at')
            ->limit(10)
            ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'stats' => $stats,
                'recent_orders' => $recentOrders,
            ],
        ]);
    }

    public function users(Request $request): JsonResponse
    {
        $query = User::query();

        if ($request->has('role')) {
            $query->where('role', $request->role);
        }

        if ($request->has('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('name', 'like', '%' . $request->search . '%')
                  ->orWhere('phone', 'like', '%' . $request->search . '%')
                  ->orWhere('email', 'like', '%' . $request->search . '%');
            });
        }

        $users = $query->orderByDesc('created_at')->paginate(20);

        return response()->json([
            'success' => true,
            'data' => $users,
        ]);
    }

    public function updateUser(Request $request, $id): JsonResponse
    {
        $user = User::findOrFail($id);

        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'email' => 'sometimes|email|max:255|unique:users,email,' . $id,
            'phone' => 'sometimes|string|max:20|unique:users,phone,' . $id,
            'role' => 'sometimes|in:customer,admin',
            'is_active' => 'sometimes|boolean',
        ]);

        $user->update($validated);

        return response()->json([
            'success' => true,
            'data' => $user,
            'message' => 'Користувача оновлено',
        ]);
    }

    public function deleteUser($id): JsonResponse
    {
        $user = User::findOrFail($id);
        
        // Не даем удалить самого себя
        if ($user->id === auth()->id()) {
            return response()->json([
                'success' => false,
                'message' => 'Не можна видалити власний обліковий запис',
            ], 400);
        }

        $user->delete();

        return response()->json([
            'success' => true,
            'message' => 'Користувача видалено',
        ]);
    }

    public function allOrders(Request $request): JsonResponse
    {
        $query = Order::with(['user', 'service', 'category', 'subcategory']);

        if ($request->has('status')) {
            $query->byStatus($request->status);
        }

        if ($request->has('search')) {
            $query->where('title', 'like', '%' . $request->search . '%');
        }

        $orders = $query->orderByDesc('created_at')->paginate(20);

        return response()->json([
            'success' => true,
            'data' => $orders,
        ]);
    }

    public function updateOrderStatus(Request $request, $id): JsonResponse
    {
        $order = Order::findOrFail($id);

        $validated = $request->validate([
            'status' => 'required|in:new,in_progress,completed,cancelled',
        ]);

        $order->update($validated);

        return response()->json([
            'success' => true,
            'data' => $order,
            'message' => 'Статус оновлено',
        ]);
    }
}
